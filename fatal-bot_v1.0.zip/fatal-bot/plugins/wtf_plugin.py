#===isfatalplugin===
# -*- coding: utf-8 -*-

#  fatal plugin
#  wtf_plugin.py

#  Copyright © 1998-2009 wd/lotusfeet <dao/yoga>

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.

#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

import sqlite3 as db
import os, time

DEFLIMIT = 2000
LISTLIMIT = 50

def querywtf(dbpath,query):
	cursor,connection = None, None
	try:
		connection=db.connect(dbpath)
		cursor=connection.cursor()
		cursor.execute(query)
		result=cursor.fetchall()
		connection.commit()
		cursor.close()
		connection.close()
		return result
	except:
		if cursor:
			cursor.close()
		if connection:
			connection.commit()
			connection.close()
		return ''

def wr_op_file(path, data):
	data = data.encode('cp1251')
	write_file(path, data)
	fp = open(path)
	return fp

def si_request(frm,fjid,sid,name,size,entity=''):
	iq = xmpp.Protocol(name = 'iq', to = fjid,
		typ = 'set')
	ID = 'si'+str(random.randrange(1000, 9999))
	iq.setID(ID)
	si = iq.setTag('si')
	si.setNamespace(xmpp.NS_SI)
	si.setAttr('profile', xmpp.NS_FILE)
	si.setAttr('id', sid)
	file_tag = si.setTag('file')
	file_tag.setNamespace(xmpp.NS_FILE)
	file_tag.setAttr('name', name)
	file_tag.setAttr('size', size)
	desc = file_tag.setTag('desc')
	desc.setData(u'Статья "%s" из базы словаря.' % (entity))
	file_tag.setTag('range')
	feature = si.setTag('feature')
	feature.setNamespace(xmpp.NS_FEATURE)
	_feature = xmpp.DataForm(typ='form')
	feature.addChild(node=_feature)
	field = _feature.setField('stream-method')
	field.setAttr('type', 'list-single')
	field.addOption(xmpp.NS_IBB)
	field.addOption('jabber:iq:oob')
	return iq

def check_reader_id(gch,reader_id):
	sql = 'SELECT * FROM readers WHERE rid="%s";' % (reader_id)
	qres = querywtf('dynamic/'+gch+'/readers.db',sql)
	
	if qres:
		return False
	else:
		return True	

def check_entity(gch,entity):
	sql = 'SELECT entity FROM defs WHERE entity="%s";' % (entity)
	qres = querywtf('dynamic/'+gch+'/def.db',sql)
	
	if qres:
		return True
	else:
		return False

def chk_rdr_ent(gch,entity,reader_id):
	sql = 'SELECT entity FROM %s WHERE entity="%s";' % (reader_id,entity)
	qres = querywtf('dynamic/'+gch+'/readers.db',sql)
	
	if qres:
		return True
	else:
		return False

def clear_nex(gch,all_wtf,reader_id):
	if all_wtf:
		nex_wtf = [nexwli for nexwli in all_wtf if not check_entity(gch,nexwli[0])]
		
		if nex_wtf:
			for nxi in nex_wtf:
				del_exp_wtf(gch,nxi[0],reader_id)
				all_wtf.remove(nxi)
	return all_wtf
		
def get_ent_count(gch):
	sql = 'SELECT entity FROM defs;'
	qres = querywtf('dynamic/'+gch+'/def.db',sql)
	
	return len(qres)
		
def get_last_wtf(gch,reader_id):
	sql = 'SELECT * FROM %s ORDER BY last DESC;' % (reader_id)
	qres = querywtf('dynamic/'+gch+'/readers.db',sql)
	
	qres = clear_nex(gch,qres,reader_id)
	
	if qres:
		return qres[0]
	else:
		return ''

def clr_rdr_blist(gch,reader_id):
	sql = 'DROP TABLE %s;' % (reader_id)
	qres = querywtf('dynamic/'+gch+'/readers.db',sql)
	
	return qres

def del_exp_wtf(gch,entity,reader_id):
	sql = 'DELETE FROM %s WHERE entity="%s";' % (reader_id,entity)
	qres = querywtf('dynamic/'+gch+'/readers.db',sql)
	
	return qres

def get_opened(gch,reader_id):
	sql = 'SELECT * FROM %s ORDER BY last DESC;' % (reader_id)
	qres = querywtf('dynamic/'+gch+'/readers.db',sql)
	
	qres = clear_nex(gch,qres,reader_id)
	
	if qres:
		return qres
	else:
		return ''

def show_opened(gch,opli):
	nopli = []
	
	if opli:
		nopli = [u'%s) %s, страница: %s из %s (зн/с: %s)' % (opli.index(oli)+1,oli[0],oli[1],oli[3],oli[2]) for oli in opli if oli[1] != oli[3]]
		return nopli
	else:
		return ''
		
def get_rdr_wtf(gch,reader_id,entity):
	sql = 'SELECT * FROM %s WHERE entity="%s";' % (reader_id,entity)
	qres = querywtf('dynamic/'+gch+'/readers.db',sql)
	
	if qres:
		return qres[0]
	else:
		return ''

def get_reader_id(gch,jid):
	sql = 'SELECT rid FROM readers WHERE jid="%s";' % (jid)
	reader_id = querywtf('dynamic/'+gch+'/readers.db',sql)
	
	if reader_id:
		return reader_id[0][0]
	else:
		return ''

def save_pos(gch,jid,entity,last,part,spart,qop,reader_id=''):
	if not reader_id:
		reader_id = 'reader'+str(random.randrange(10000000, 99999999))
		chk_rid = check_reader_id(gch,reader_id)
		
		while not chk_rid:
			reader_id = 'reader'+str(random.randrange(10000000, 99999999))
			chk_rid = check_reader_id(gch,reader_id)
		
		sql = 'INSERT INTO readers (jid,rid) VALUES ("%s","%s");' % (jid,reader_id)
		res = querywtf('dynamic/'+gch+'/readers.db',sql)
	
		sql = 'CREATE TABLE %s (entity varchar not null, part varchar not null, spart varchar not null, qop varchar not null, last varchar not null,unique (entity))' % (reader_id)
		res = querywtf('dynamic/'+gch+'/readers.db',sql)
	
	sql = 'INSERT INTO %s (entity,part,spart,qop,last) VALUES ("%s","%s","%s","%s","%s");' % (reader_id,entity,part,spart,qop,last)
	res = querywtf('dynamic/'+gch+'/readers.db',sql)
	
	if res == '':
		upd_sql = 'UPDATE %s SET "part"="%s", "spart"="%s", "qop"="%s", "last"="%s" WHERE entity="%s";' % (reader_id,part,spart,qop,last,entity)
		res = querywtf('dynamic/'+gch+'/readers.db',upd_sql)
	
	if res == '':
		sql = 'CREATE TABLE %s (entity varchar not null, part varchar not null, spart varchar not null, qop varchar not null, last varchar not null,unique (entity))' % (reader_id)
		res = querywtf('dynamic/'+gch+'/readers.db',sql)
		
		sql = 'INSERT INTO %s (entity,part,spart,qop,last) VALUES ("%s","%s","%s","%s","%s");' % (reader_id,entity,part,spart,qop,last)
		res = querywtf('dynamic/'+gch+'/readers.db',sql)

	return res
		
def get_part_list(entli,part,quantity):
	if not entli:
		return entli
	
	qtt = len(entli)
	
	if qtt <= quantity:
		qofparts = 1
		quantity = qtt
	else:
		qofparts = qtt/quantity
		isadparts = qtt%quantity
		 
		if isadparts:
			qofparts += 1
			
	if part > qofparts:
		part = qofparts
	
	startind = part * quantity - quantity
	endind = part * quantity
	
	prtli = entli[startind:endind]
	
	return (prtli,part,quantity,qofparts,startind)		
		
def get_ent_list(gch):
	sql = 'SELECT entity FROM defs ORDER BY entity;'
	qres=querywtf('dynamic/'+gch+'/def.db',sql)
	
	if qres:
		qres = [li[0] for li in qres]
		return qres
	else:
		return ''
		
def get_book_list(gch):
	sql = u'SELECT entity FROM defs WHERE author="книга" ORDER BY entity;'
	qres=querywtf('dynamic/'+gch+'/def.db',sql)
	
	if qres:
		qres = [li[0] for li in qres]
		return qres
	else:
		return ''
		
def get_part(gdef,part,spart=DEFLIMIT):
	if not gdef:
		return gdef
	
	gdef = gdef.encode('utf-8')
	
	qtt = len(gdef)
	
	if qtt <= spart:
		qofparts = 1
		spart = qtt
	else:
		qofparts = qtt/spart
		isadparts = qtt%spart
		 
		if isadparts:
			qofparts += 1
			
	if part > qofparts:
		part = qofparts
	
	startind = part * spart - spart
	endind = part * spart
	
	if part == 1 and qofparts != part:
		endind = gdef.find(' ',endind)
	elif part == 1 and qofparts == part:
		endind = qtt
	elif part == qofparts:
		startind = gdef.find(' ',startind)
		endind = qtt
	else:
		startind = gdef.find(' ',startind)
		endind = gdef.find(' ',endind)
	
	opart = gdef[startind:endind]
	opart = opart.decode('utf-8')
	
	if len(opart) < spart:
		spart = len(opart)	
	
	return (opart.strip(),part,spart,qofparts,startind)

def add_def(gch,entity,gdef,author=''):
#-----------------------Local Functions--------------
	
	def filter_ent(entity):
		for I in ['"','!','?','~','`','@','#','$','%','^','&','*','(',')','-','=','+','[',']','{','}','|','\\','/',';',':','\'','<','>','.']:
			entity = entity.replace(I,'')
		
		return entity.lower()
		
	def load_def(path):
		try:
			fp = open(path)
			fgdef = fp.read()
			fp.close
			return fgdef
		except:
			return ''
		
#-----------------------End Of Local Functions--------------
	
	if len(gdef) <= 255:
		if os.path.exists(gdef):
			tmp_gdef = load_def(gdef.strip())
			
			if tmp_gdef.strip():
				gdef = tmp_gdef.decode('utf-8')
	
	entity = filter_ent(entity)
	gdef = gdef.replace('"','&quot;')
	author = author.replace('"','&quot;')
	
	action = ''
	
	if not check_entity(gch,entity):
		sql = 'INSERT INTO defs (entity,def,author) VALUES ("%s","%s","%s");' % (entity.strip(),gdef.strip(),author)
		action = 'a'
	else:
		sql = 'UPDATE defs SET "def"="%s", "author"="%s" WHERE entity="%s";' % (gdef.strip(),author,entity.strip())
		action = 'u'
	
	qres = querywtf('dynamic/'+gch+'/def.db',sql)
	
	if qres != '':
		return (action,entity)
	else:	
		return qres
		
def del_def(gch,entity):
	del_sql = 'DELETE FROM defs WHERE entity="%s";' % (entity)
	qres = querywtf('dynamic/'+gch+'/def.db',del_sql)
	return qres		
		
def get_def(gch,entity):
	sql = 'SELECT def,entity FROM defs WHERE entity LIKE "'+entity+'%" ORDER BY entity LIMIT 1;'
	qres = querywtf('dynamic/'+gch+'/def.db',sql)
	
	if qres:
		return (qres[0][0],qres[0][1])
	else:
		return ''
		
def get_rnd_def(gch):
	sql = 'SELECT * FROM defs ORDER BY RANDOM() LIMIT 1;'
	qres = querywtf('dynamic/'+gch+'/def.db',sql)
	
	if qres:
		return (qres[0][0],qres[0][1],qres[0][2])
	else:
		return ''
		
def find_ent_def(gch,key):
	sql = 'SELECT entity FROM defs WHERE entity LIKE "%'+key+'%" ORDER BY entity;'
	ent_res = querywtf('dynamic/'+gch+'/def.db',sql)
	
	sql = 'SELECT entity FROM defs WHERE def LIKE "%'+key+'%" ORDER BY entity;'
	def_res = querywtf('dynamic/'+gch+'/def.db',sql)
	
	ent_list = []
	def_list = []
	
	if ent_res:
		ent_list = [eli[0] for eli in ent_res if eli[0]]
		
	if def_res:
		def_list = [dli[0] for dli in def_res if dli[0]]	
	
	return (ent_list,def_list)

def get_wtf_state(gch):
	if not os.path.exists('dynamic/'+gch+'/def.db'):
		sql = 'CREATE TABLE defs (entity varchar, def varchar, author varchar)'
		querywtf('dynamic/'+gch+'/def.db',sql)
	if not os.path.exists('dynamic/'+gch+'/readers.db'):
		sql = 'CREATE TABLE readers (jid varchar, rid varchar, unique (rid))'
		querywtf('dynamic/'+gch+'/readers.db',sql)

def handler_wtf(type, source, parameters):
	groupchat=source[1]
	nick = source[2]
	jid = get_true_jid(groupchat+'/'+nick)
	
	if not GROUPCHATS.has_key(groupchat):
		reply(type, source, u'Эта команда может быть использована только в конференции!')
		return
	
	if parameters:
		parsepar = parameters.split(' ')
		parsepar.append(' ')
		
		part = parsepar[0]
		spart = parsepar[1]
		
		if not spart.isalpha() and (spart[-1] == 'k'):
			spart = int(spart[:-1]) * 1000
			spart = str(spart)
		elif not part.isalpha() and (part[-1] == 'k'):
			part = int(part[:-1]) * 1000
			part = str(part)
			
		if part.isdigit() and not spart.isdigit():
			part = int(part)
			spart = DEFLIMIT			
			entity = parsepar[1:]
			entity = ' '.join(entity)
			entity = entity.strip()
		elif not part.isdigit() and not spart.isdigit():
			part = 1
			spart = DEFLIMIT
			entity = ' '.join(parsepar)
			entity = entity.strip()
		else:
			part = int(part)
			spart = int(spart)
			entity = parsepar[2:]
			entity = ' '.join(entity)
			entity = entity.strip()
		
		tdef = get_def(groupchat,entity)
		gdef = ''
		
		if tdef:
			gdef = tdef[0]
			entity = tdef[1]
		
		if gdef:
			prt = get_part(gdef,part,spart)
			
			reader_id = get_reader_id(groupchat,jid)
			
			if prt[3] > 1:
				save_pos(groupchat,jid,entity,time.time(),prt[1],spart,prt[3],reader_id)
			
			pref = ''
			suff = ''
			
			if prt[1] > 1:
				pref = '...] '
			if prt[1] != prt[3]:
				suff = ' [...'
			
			if pref or suff:
				rep = u'Статья (название: %s; страница: %s из %s): %s%s%s' % (entity,prt[1],prt[3],pref,prt[0].replace('&quot;','"'),suff)
			else:
				rep = u'Статья (название: %s): %s' % (entity,prt[0].replace('&quot;','"'))
				
			reply(type, source, rep)
		else:
			reply(type, source, u'Статья с названием "%s" не найдена в словаре!' % (entity))
	else:
		reply(type, source, u'Неверный синтаксис!')

def handler_prev(type, source, parameters):
	groupchat=source[1]
	nick = source[2]
	jid = get_true_jid(groupchat+'/'+nick)
	
	if not GROUPCHATS.has_key(groupchat):
		reply(type, source, u'Эта команда может быть использована только в конференции!')
		return
	
	decpart = 1
	reader_id = get_reader_id(groupchat,jid)
	last_wtf = get_last_wtf(groupchat,reader_id)
	
#-----------------------Local Functions--------------
	
	def out_part(groupchat,jid,entity,part,spart,reader_id,force=False,rnow=False):
		tdef = get_def(groupchat,entity)
		gdef = tdef[0]
		prt = get_part(gdef,part,spart)
		
		if prt[1] != 1 or force:
			save_pos(groupchat,jid,entity,time.time(),prt[1],spart,prt[3],reader_id)
		
		pref = ''
		suff = ''
		
		if prt[1] > 1:
			pref = '...] '
		if prt[1] != prt[3]:
			suff = ' [...'
		
		if not rnow:
			if pref or suff:
				rep = u'Статья (название: %s; страница: %s из %s): %s%s%s' % (entity,prt[1],prt[3],pref,prt[0].replace('&quot;','"'),suff)
			else:
				rep = u'Статья (название: %s): %s' % (entity,prt[0].replace('&quot;','"'))
		else:
			if pref or suff:
				rep = u'- %s/%s -\n\n%s%s%s\n\n- %s/%s -' % (prt[1],prt[3],pref,prt[0].replace('&quot;','"'),suff,prt[1],prt[3])
			else:
				rep = u'Статья (название: %s): %s' % (entity,prt[0].replace('&quot;','"'))
		
		return rep
			
#-----------------------End Of Local Functions--------------
	
	if not last_wtf:
		reply(type, source, u'Не задана статья!')
		return
	
	if parameters:
		spltdp = parameters.split(' ',1)
		
		entity = ''
		
		if len(spltdp) >= 1:
			entstp = spltdp[0]
			
			if entstp.isdigit():
				decpart = int(entstp)
				
				if decpart <= 0:
					decpart = 1
			else:
				entity = parameters
				
			if entity:
				if chk_rdr_ent(groupchat,entity,reader_id):
					gwtf = get_rdr_wtf(groupchat,reader_id,entity)
					
					part = int(gwtf[1])
					spart = int(gwtf[2])
					rpos = int(gwtf[3])
					
					rep = out_part(groupchat,jid,entity,part,spart,reader_id,force=True)
					reply(type, source, rep)
				elif check_entity(groupchat,entity):
					part = 1
					spart = DEFLIMIT
					rpos = 0
					
					rep = out_part(groupchat,jid,entity,part,spart,reader_id)
					reply(type, source, rep)
				else:
					reply(type, source, u'Не найдено: %s' % (entity))
					return
			else:
				entity = last_wtf[0]
				
				part = int(last_wtf[1])
				prev_part = part - decpart
				
				if prev_part <= 0:
					prev_part = 1

				spart = int(last_wtf[2])
				rpos = int(last_wtf[3])
				
				rep = out_part(groupchat,jid,entity,prev_part,spart,reader_id,rnow=True)
				reply(type, source, rep)
		else:	
			reply(type, source, u'Неверный синтаксис!')
	else:
		entity = last_wtf[0]
		
		currtm = time.time()
		last = float(last_wtf[4])
		tmlong = int(round(currtm - last))
		
		part = int(last_wtf[1])
		
		rnow = False
		
		if tmlong <= 900:
			rnow = True
			prev_part = part - decpart
		else:
			prev_part = part
		
		if prev_part <= 0:
			prev_part = 1
		
		spart = int(last_wtf[2])
		rpos = int(last_wtf[3])
		
		rep = out_part(groupchat,jid,entity,prev_part,spart,reader_id,rnow=rnow)
		reply(type, source, rep)

def handler_next(type, source, parameters):
	groupchat=source[1]
	nick = source[2]
	jid = get_true_jid(groupchat+'/'+nick)
	
	if not GROUPCHATS.has_key(groupchat):
		reply(type, source, u'Эта команда может быть использована только в конференции!')
		return
	
	incpart = 1
	reader_id = get_reader_id(groupchat,jid)
	last_wtf = get_last_wtf(groupchat,reader_id)
	
#-----------------------Local Functions--------------
	
	def out_part(groupchat,jid,entity,part,spart,reader_id,force=False,rnow=False):
		tdef = get_def(groupchat,entity)
		gdef = tdef[0]
		prt = get_part(gdef,part,spart)
		
		if prt[3] != prt[1] or force:
			save_pos(groupchat,jid,entity,time.time(),prt[1],spart,prt[3],reader_id)
		else:
			del_exp_wtf(groupchat,entity,reader_id)
		
		pref = ''
		suff = ''
		
		if prt[1] > 1:
			pref = '...] '
		if prt[1] != prt[3]:
			suff = ' [...'
		
		if not rnow:
			if pref or suff:
				rep = u'Статья (название: %s; страница: %s из %s): %s%s%s' % (entity,prt[1],prt[3],pref,prt[0].replace('&quot;','"'),suff)
			else:
				rep = u'Статья (название: %s): %s' % (entity,prt[0].replace('&quot;','"'))
		else:
			if pref or suff:
				rep = u'- %s/%s -\n\n%s%s%s\n\n- %s/%s -' % (prt[1],prt[3],pref,prt[0].replace('&quot;','"'),suff,prt[1],prt[3])
			else:
				rep = u'Статья (название: %s): %s' % (entity,prt[0].replace('&quot;','"'))
		
		return rep
			
#-----------------------End Of Local Functions--------------
	
	if not last_wtf:
		reply(type, source, u'Не задана статья!')
		return
	
	if parameters:
		spltdp = parameters.split(' ',1)
		
		entity = ''
		
		if len(spltdp) >= 1:
			entstp = spltdp[0]
			
			if entstp.isdigit():
				incpart = int(entstp)
				
				if incpart <= 0:
					incpart = 1
			else:
				entity = parameters
				
			if entity:
				if chk_rdr_ent(groupchat,entity,reader_id) and check_entity(groupchat,entity):
					gwtf = get_rdr_wtf(groupchat,reader_id,entity)
					
					part = int(gwtf[1])
					spart = int(gwtf[2])
					rpos = int(gwtf[3])
					
					rep = out_part(groupchat,jid,entity,part,spart,reader_id,force=True)
					reply(type, source, rep)
				elif check_entity(groupchat,entity):
					part = 1
					spart = DEFLIMIT
					rpos = 0
					
					rep = out_part(groupchat,jid,entity,part,spart,reader_id)
					reply(type, source, rep)
				else:
					reply(type, source, u'Статья с названием "%s" не найдена в словаре!' % (entity))
					return
			else:
				entity = last_wtf[0]
				
				part = int(last_wtf[1])
				next_part = part + incpart
				
				spart = int(last_wtf[2])
				rpos = int(last_wtf[3])
				
				rep = out_part(groupchat,jid,entity,next_part,spart,reader_id,rnow=True)
				reply(type, source, rep)
		else:	
			reply(type, source, u'Неверный синтаксис!')
	else:
		entity = last_wtf[0]
		
		currtm = time.time()
		last = float(last_wtf[4])
		tmlong = int(round(currtm - last))
		
		part = int(last_wtf[1])
		
		rnow = False
		
		if tmlong <= 900:
			rnow = True
			next_part = part + incpart
		else:
			next_part = part
		
		spart = int(last_wtf[2])
		rpos = int(last_wtf[3])
		
		rep = out_part(groupchat,jid,entity,next_part,spart,reader_id,rnow=rnow)
		reply(type, source, rep)

def handler_list(type, source, parameters):
	groupchat=source[1]
	nick = source[2]
	jid = get_true_jid(groupchat+'/'+nick)
	
	if not GROUPCHATS.has_key(groupchat):
		reply(type, source, u'Эта команда может быть использована только в конференции!')
		return
	
#-----------------------Local Functions--------------

	def out_list(entli,part,quantity):
		if entli:
			prt = get_part_list(entli,part,quantity)
			elist = prt[0]
		
			pref = ''
			suff = '.'
			
			if prt[1] > 1:
				pref = '...] '
			if prt[1] != prt[3]:
				suff = ', [...'
			
			if pref or suff:
				rep =u'Cписок статей (показано: %s из %s; страница: %s из %s): %s%s%s' %(len(elist),len(entli),prt[1],prt[3],pref,', '.join(elist),suff)
			else:
				rep =u'Cписок статей (всего: %s): %s.' %(len(entli),', '.join(elist))
		else:
			rep = u'База пуста!'
		
		return rep
			
#-----------------------End Of Local Functions--------------
	
	if parameters:
		parsepar = parameters.split(' ',2)
		
		part = parsepar[0]
		quantity = ''
		
		if len(parsepar) == 2:
			quantity = parsepar[1]
		
		if len(parsepar) == 2 and part.isdigit() and quantity.isdigit():
			part = int(part)
			quantity = int(quantity)			
		elif len(parsepar) == 1 and part.isdigit():
			part = int(part)
			quantity = LISTLIMIT
		else:
			reply(type, source, u'Неверный синтаксис!')
			return
			
		entli = get_ent_list(groupchat)
		
		rep = out_list(entli,part,quantity)
		reply(type, source, rep)
			
	else:
		entli = get_ent_list(groupchat)
		rep = out_list(entli,1,LISTLIMIT)
		reply(type, source, rep)

def handler_books(type, source, parameters):
	groupchat=source[1]
	nick = source[2]
	jid = get_true_jid(groupchat+'/'+nick)
	
	if not GROUPCHATS.has_key(groupchat):
		reply(type, source, u'Эта команда может быть использована только в конференции!')
		return
	
#-----------------------Local Functions--------------

	def out_list(entli,part,quantity):
		if entli:
			prt = get_part_list(entli,part,quantity)
			elist = prt[0]
		
			pref = ''
			suff = '.'
			
			if prt[1] > 1:
				pref = '...] '
			if prt[1] != prt[3]:
				suff = ', [...'
			
			if pref or suff:
				rep =u'Cписок статей (показано: %s из %s; страница: %s из %s): %s%s%s' %(len(elist),len(entli),prt[1],prt[3],pref,', '.join(elist),suff)
			else:
				rep =u'Cписок книг (всего: %s): %s.' %(len(entli),', '.join(elist))
		else:
			rep = u'Книг нет!'
		
		return rep
			
#-----------------------End Of Local Functions--------------
	
	if parameters:
		parsepar = parameters.split(' ',2)
		
		part = parsepar[0]
		quantity = ''
		
		if len(parsepar) == 2:
			quantity = parsepar[1]
		
		if len(parsepar) == 2 and part.isdigit() and quantity.isdigit():
			part = int(part)
			quantity = int(quantity)			
		elif len(parsepar) == 1 and part.isdigit():
			part = int(part)
			quantity = LISTLIMIT
		else:
			reply(type, source, u'Неверный синтаксис!')
			return
			
		entli = get_book_list(groupchat)
		
		rep = out_list(entli,part,quantity)
		reply(type, source, rep)	
	else:
		entli = get_book_list(groupchat)
		rep = out_list(entli,1,LISTLIMIT)
		reply(type, source, rep)

def handler_stat(type, source, parameters):
	groupchat=source[1]
	nick = source[2]
	jid = get_true_jid(groupchat+'/'+nick)
	
	if not GROUPCHATS.has_key(groupchat):
		reply(type, source, u'Эта команда может быть использована только в конференции!')
		return
	
	reader_id = get_reader_id(groupchat,jid)
	opli = get_opened(groupchat,reader_id)

	if not parameters:
		if opli:
			nopli = show_opened(groupchat,opli)
			
			if nopli:
				rep = u'Открытые книги (всего: %s):\n\n%s' % (len(nopli),'\n'.join(nopli))
			else:
				rep = u'Нет открытых книг!'
			
			reply(type, source, rep)
		else:
			reply(type, source, u'Нет открытых книг!')
	else:
		bnum = parameters[1:]
		
		if not opli:
			reply(type, source, u'Нет открытых книг!')
			return
		
		if bnum.isdigit() and parameters[0] == '-' and len(parameters) >= 2:
			if int(bnum) <= len(opli):
				dbki = int(bnum) - 1
				entity = opli[dbki][0]
				res = del_exp_wtf(groupchat,entity,reader_id)
				
				if res != '':
					reply(type, source, u'Книга с названием "%s" закрыта!' % (entity))
				else:
					reply(type, source, u'Невозможно закрыть книгу!')
			else:
				reply(type, source, u'Неверный номер открытой книги!')
		elif len(parameters) == 1 and parameters[0] == '-':
			res = clr_rdr_blist(groupchat,reader_id)
			
			if res != '':
				reply(type, source, u'Все открытые книги закрыты!')
			else:
				reply(type, source, u'Невозможно закрыть книги!')
		else:
			reply(type, source, u'Неверный синтаксис!')
		
def handler_dfn(type, source, parameters):
	groupchat=source[1]
	nick = source[2]

	if not GROUPCHATS.has_key(groupchat):
		reply(type, source, u'Эта команда может быть использована только в конференции!')
		return

	if parameters:
		parsepar = parameters.split('=',1)
		
		if len(parsepar) == 2:
			entity = parsepar[0]
			gdef = parsepar[1]
			author = nick
			
			if not entity.strip():
				reply(type, source, u'У статьи должно быть название!')
				return
			elif not gdef.strip():
				reply(type, source, u'Статья не может быть пустой!')
				return
			
			ent_len = len(entity.split())
			
			if ent_len <= 5:
				res = add_def(groupchat,entity,gdef,author)
				
				if res:
					if res[0] == 'a':
						rep = u'Новая статья с названием "%s" добавлена в словарь!' % (res[1])
					elif res[0] == 'u':
						rep = u'Cтатья с названием "%s" обновлена в словаре!' % (res[1])
				else:
					rep = u'Ошибка добавления!'
					
				reply(type, source, rep)
			else:
				reply(type, source, u'Название статьи должно быть длинной не более пяти слов!')
		else:
			reply(type, source, u'Неверный синтаксис!')
	else:
		reply(type, source, u'Неверный синтаксис!')
		
def handler_del(type, source, parameters):
	groupchat=source[1]

	if not GROUPCHATS.has_key(groupchat):
		reply(type, source, u'Эта команда может быть использована только в конференции!')
		return

	if parameters:
		entity = parameters.strip()
		
		if check_entity(groupchat,entity):
			res = del_def(groupchat,entity)
		else:
			reply(type, source, u'Статья с названием "%s" не найдена в словаре!' % (entity))
			return
		
		if res != '':
			rep = u'Статья с названием "%s" удалена из словаря!' % (entity)
		else:
			rep = u'Ошибка удаления!'
			
		reply(type, source, rep)			
	else:
		reply(type, source, u'Неверный синтаксис!')
		
def handler_rnd(type, source, parameters):
	groupchat=source[1]
	nick = source[2]
	jid = get_true_jid(groupchat+'/'+nick)
	
	if not GROUPCHATS.has_key(groupchat):
		reply(type, source, u'Эта команда может быть использована только в конференции!')
		return
	
	if not parameters:
		res = get_rnd_def(groupchat)
		
		if res != '':
			entity = res[0]
			gdef = res[1]
			prt = get_part(gdef,1,DEFLIMIT)
			
			reader_id = get_reader_id(groupchat,jid)
			
			if prt[3] > 1:
				save_pos(groupchat,jid,entity,time.time(),prt[1],DEFLIMIT,prt[3],reader_id)
			
			pref = ''
			suff = ''
			
			if prt[1] > 1:
				pref = '...] '
			if prt[1] != prt[3]:
				suff = ' [...'
			
			if pref or suff:
				rep = u'Cтатья, выбранная случайным образом (название: %s; страница: %s из %s): %s%s%s' % (entity,prt[1],prt[3],pref,prt[0].replace('&quot;','"'),suff)
			else:
				rep = u'Cтатья, выбранная случайным образом (название: %s): %s' % (entity,prt[0].replace('&quot;','"'))
				
			reply(type, source, rep)
		else:
			reply(type, source, u'Неудачно!')
	else:
		reply(type, source, u'Неверный синтаксис!')

def handler_find(type, source, parameters):
	groupchat=source[1]
	
	if not GROUPCHATS.has_key(groupchat):
		reply(type, source, u'Эта команда может быть использована только в конференции!')
		return
	
	if parameters:
		key = parameters.strip()
		ent_def_res = find_ent_def(groupchat,key)
		
		rep = ''
		
		ent_list = ent_def_res[0]
		def_list = ent_def_res[1]
		
		if ent_list:
			rep += u'Найдено в названии статей (всего: %d): %s.' % (len(ent_list),', '.join(ent_list))
			
		if def_list:
			rep += u'\n\nНайдено в тексте статей (всего: %d): %s.' % (len(def_list),', '.join(def_list))
			
		if rep:
			reply(type, source, rep.strip())
		else:
			reply(type, source, u'Ничего не найдено!')
	else:
		reply(type, source, u'Неверный синтаксис!')

def handler_search(type, source, parameters):
	groupchat=source[1]
	nick = source[2]
	jid = get_true_jid(groupchat+'/'+nick)

	if not GROUPCHATS.has_key(groupchat):
		reply(type, source, u'Эта команда может быть использована только в конференции!')
		return

#-----------------------Local Functions--------------
	
	def out_part(groupchat,jid,entity,pgdef,part,qofparts,reader_id):
		if qofparts != part:
			save_pos(groupchat,jid,entity,time.time(),part,DEFLIMIT,qofparts,reader_id)
		
		pref = ''
		suff = ''
		
		if prt[1] > 1:
			pref = '...] '
		if prt[1] != prt[3]:
			suff = ' [...'
		
		if pref or suff:
			rep = u'Статья (название: %s; страница: %s из %s): %s%s%s' % (entity,part,qofparts,pref,pgdef.replace('&quot;','"'),suff)
		else:
			rep = u'Статья (название: %s): %s' % (entity,pgdef.replace('&quot;','"'))
		
		return rep
			
#-----------------------End Of Local Functions--------------

	reader_id = get_reader_id(groupchat,jid)

	if parameters:
		parsepar = parameters.split(':',1)
		
		if len(parsepar) == 2:
			entity = parsepar[0].strip()
			qstr = parsepar[1].strip()
				
			if qstr:
				if entity:
					if check_entity(groupchat,entity):
						tdef = get_def(groupchat,entity)
						gdef = tdef[0]
						prt = get_part(gdef,1)
						
						qofparts = prt[3]
						pgdef = prt[0]
						pglist = []
						
						if pgdef.find(qstr) != -1:
							pglist.append(1)
						
						pind = 2
						prt = get_part(gdef,pind)
						pgdef = prt[0]
						
						while pind != qofparts + 1:
							if pgdef.find(qstr) != -1:
								pglist.append(pind)
							
							pind += 1
							prt = get_part(gdef,pind)
							pgdef = prt[0]
					
						if pglist:
							prt = get_part(gdef,pglist[0])
							strpgli = [str(sli) for sli in pglist[1:]]
							pgdef = prt[0]
							
							rep = out_part(groupchat,jid,entity,pgdef,prt[1],qofparts,reader_id)
							
							if strpgli:
								rep += u'\n\nТакже совпадения найдены на страницах (всего: %d): %s.' % (len(strpgli), ', '.join(strpgli))
								
							reply(type, source, rep.replace(qstr,' -> '+qstr.upper()+' <- '))
						else:
							reply(type, source, u'Ничего не найдено!')
					else:
						reply(type, source, u'Статья с названием "%s" не найдена в словаре!' % (entity))
				else:
					reply(type, source, u'Не указана статья!')
			else:
				reply(type, source, u'Пустая строка поиска!')
		else:
			reply(type, source, u'Неверный синтаксис!')
	else:
		reply(type, source, u'Неверный синтаксис!')

def handler_count(type, source, parameters):
	groupchat=source[1]

	if not GROUPCHATS.has_key(groupchat):
		reply(type, source, u'Эта команда может быть использована только в конференции!')
		return

	ent_count = get_ent_count(groupchat)
	
	if ent_count != 0:
		rep = u'Количество статей в словаре: %d'% (ent_count)
	else:
		rep = u'База пуста!'
		
	reply(type, source, rep)

def handler_get_wtf(type, source, parameters):
	groupchat=source[1]
	nick = source[2]

	if not GROUPCHATS.has_key(groupchat):
		reply(type, source, u'Эта команда может быть использована только в конференции!')
		return
	
	if parameters:
		entity = parameters.strip()
		gdef = get_def(groupchat,entity)
		
		if gdef:
			data = gdef[0].replace('&quot;','"')
			entity = gdef[1]
		else:
			reply(type, source, u'Статья с названием "%s" не найдена в словаре!' % (entity))
			return
		
		to = ''
		
		if GROUPCHATS[groupchat].has_key(nick):
			to = GROUPCHATS[groupchat][nick]['jid']
		
		if not to:
			reply(type, source, u'Внутреняя ошибка, невозможно выполнить операцию!')
			return
		
		sid = 'file'+str(random.randrange(10000000, 99999999))
		name = sid+'.txt'
		
		fp = wr_op_file('dynamic/'+name, data)
		
		frm = JID+'/'+RESOURCE
		
		sireq = si_request(frm,to,sid,name,len(data),entity)
		JCON.SendAndCallForResponse(sireq, handler_load_answ, args={'type':type,'source':source,'sid':sid,'to':to,'fp':fp})
	else:
		reply(type, source, u'Неверный синтаксис!')
		
def handler_load_answ(coze,resp,type,source,sid,to,fp):
	rtype = resp.getType()
	
	if rtype == 'result':
		JCON.IBB.OpenStream(sid,to,fp,1024)
		name = fp.name
		os.remove(name)
	else:
		name = fp.name
		fp.close()
		os.remove(name)
		reply(type, source, u'Неудачная передача!')

register_command_handler(handler_wtf, COMM_PREFIX+'wtf', ['info','wtf','all','*'], 11, 'Выводит статью из базы. Целиком, если статья небольшая или первую страницу размером %s символов, по умолчанию, если статья большая. Также позволяет получать и остальные страницы и задавать размер страницы в символах, если статья более %s символов.' %(DEFLIMIT,DEFLIMIT), COMM_PREFIX+'wtf [<номер_страницы>[<размер_страницы>[k]]] <название_статьи>', [COMM_PREFIX+'wtf статья', COMM_PREFIX+'wtf 3 статья', COMM_PREFIX+'wtf 44 статья', COMM_PREFIX+'wtf 3 10k большая статья', COMM_PREFIX+'wtf 5 1000 большая статья'])
register_command_handler(handler_next, COMM_PREFIX+'next', ['info','wtf','all','*'], 11, 'Позволяет получить следующие страницы статьи. Без параметров выводит следующую страницу статьи из базы, после вывода командой %swtf, если размер страницы меньше размера статьи и не указан шаг. При указании шага выводит страницу с номером равным номеру текущей страницы + шаг. При указании названия статьи, она становится текущей, т.е. при следующем вызове команды %snext будет выведена следующая страница данной статьи.' % (COMM_PREFIX,COMM_PREFIX), COMM_PREFIX+'next [<название_статьи>]|[<шаг>]', [COMM_PREFIX+'next',COMM_PREFIX+'next статья', COMM_PREFIX+'next 2'])
register_command_handler(handler_prev, COMM_PREFIX+'prev', ['info','wtf','all','*'], 11, 'Позволяет получить предыдущие страницы статьи. Без параметров выводит предыдущую страницу статьи из базы, после вывода командой %swtf, если размер страницы меньше размера статьи и не указан шаг. При указании шага выводит страницу с номером равным номеру текущей страницы - шаг. При указании названия статьи, она становится текущей, т.е. при следующем вызове команды %sprev будет выведена предыдущая страница данной статьи.' % (COMM_PREFIX,COMM_PREFIX), COMM_PREFIX+'prev [<название_статьи>]|[<шаг>]', [COMM_PREFIX+'prev',COMM_PREFIX+'prev статья', COMM_PREFIX+'prev 3'])
register_command_handler(handler_list, COMM_PREFIX+'list', ['info','wtf','all','*'], 11, 'Позволяет получить список статей, целиком или по частям. Без параметров выводит весь список статей если статей меньше %s, или часть списка размером %s названий, если статей больше %s.' % (LISTLIMIT,LISTLIMIT,LISTLIMIT), COMM_PREFIX+'list [<страница>][<размер>]', [COMM_PREFIX+'list', COMM_PREFIX+'list 3', COMM_PREFIX+'list 2 20'])
register_command_handler(handler_books, COMM_PREFIX+'books', ['info','wtf','all','*'], 11, 'Позволяет получить список книг, целиком или по частям. Без параметров выводит весь список книг если книг меньше %s, или часть списка размером %s названий, если книг больше %s.' % (LISTLIMIT,LISTLIMIT,LISTLIMIT), COMM_PREFIX+'books [<страница>][<размер>]', [COMM_PREFIX+'books', COMM_PREFIX+'books 3', COMM_PREFIX+'books 2 20'])
register_command_handler(handler_stat, COMM_PREFIX+'stat', ['info','wtf','all','*'], 11, 'Позволяет получить статистику по открытым книгам. При указании отрицательного целого числа закрывает книгу с этим номером.', COMM_PREFIX+'stat [-<номер>]', [COMM_PREFIX+'stat',COMM_PREFIX+'stat -3'])
register_command_handler(handler_dfn, COMM_PREFIX+'dfn', ['info','wtf','all','*'], 11, 'Добавляет новую, или обновляет уже существующую, статью. При указании вместо текста статьи пути до текстового файла со статьей, добавляет статью из текстового файла.', COMM_PREFIX+'dfn <название>=<тело_статьи>', [COMM_PREFIX+'dfn первая статья=Статья, такая статья'])
register_command_handler(handler_del, COMM_PREFIX+'del', ['info','wtf','all','*'], 20, 'Удаляет статью с указанным именем из словаря.', COMM_PREFIX+'del <название>', [COMM_PREFIX+'del первая статья'])
register_command_handler(handler_rnd, COMM_PREFIX+'rnd', ['info','wtf','all','*'], 11, 'Выводит случайную статью из словаря.', COMM_PREFIX+'rnd', [COMM_PREFIX+'rnd'])
register_command_handler(handler_find, COMM_PREFIX+'find', ['info','wtf','all','*'], 11, 'Ищет слова или фразы в названиях и тексте статей.', COMM_PREFIX+'find <слово>|<фраза>', [COMM_PREFIX+'find жизнь',COMM_PREFIX+'find что-то интересное'])
register_command_handler(handler_search, COMM_PREFIX+'search', ['info','wtf','all','*'], 11, 'Ищет слова или фразы в тексте указанной статьи и выводит страницу на которой найдено искомое слово или фраза.', COMM_PREFIX+'search <статья>:<слово>|<фраза>', [COMM_PREFIX+'search книга: загадка'])
register_command_handler(handler_count, COMM_PREFIX+'count', ['info','wtf','all','*'], 11, 'Выводит количество статей в словаре.', COMM_PREFIX+'count', [COMM_PREFIX+'count'])
register_command_handler(handler_get_wtf, COMM_PREFIX+'get_wtf', ['info','wtf','all','*'], 11, 'Посылает статью из словаря через джаббер файлом.', COMM_PREFIX+'get_wtf <название_статьи>', [COMM_PREFIX+'get_wtf книга'])

register_stage1_init(get_wtf_state)