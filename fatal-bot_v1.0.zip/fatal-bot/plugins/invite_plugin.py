#===istalismanplugin===
# -*- coding: utf-8 -*-

#  Talisman plugin
#  invite_plugin.py

#  Initial Copyright © 2008 Als <Als@exploit.in>
#  Modifications Copyright © 2009 wd/lotusfeet <dao/yoga>

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.

#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

def get_jid(gch, nick):
	nick = nick.replace('"','&quot;')
	sql = 'SELECT jid FROM users WHERE nick="%s";' % (nick)
	qres = querymuc('dynamic/'+gch+'/users.db',sql)
	
	if qres:
		jid = qres[0][0]
		return jid
	else:
		return ''

def check_jid(jid):
	parse_jid = jid.split('@')
	
	if len(parse_jid) == 2:
		if parse_jid[0] and parse_jid[1]:
			if parse_jid[1].count('.') >= 1 and parse_jid[1].count('.') <= 3:
				return True
			else:
				return False	
		else:
			return False
	else:
		return False

def split_reason(parameters):
	nijirel = parameters.split(':', 1)
	splited = ['','']	
		
	if len(nijirel) == 1:
		splited[0] = nijirel[0].strip()
		splited[1] = ''
	elif len(nijirel) == 2:
		splited[0] = nijirel[0].strip()
		splited[1] = nijirel[1].strip()
	return splited

def handler_invite_start(type, source, parameters):
	jid,nick_jid,reason='','',''
	groupchat = source[1]
	nick = source[2]
	
	if not GROUPCHATS.has_key(groupchat):
		reply(type, source, u'Эта команда может быть использована только в конференции!')
		return
	
	sparams = split_reason(parameters)
	
	nick_jid = sparams[0]
	reason = sparams[1]
	
	if parameters:
		if not check_jid(nick_jid):
			jid = get_jid(groupchat,nick_jid)
			
			if not jid:
				reply(type,source,u'Ты уверен, что \"'+nick_jid+u'\" был тут?')
				return
		else:
			jid = nick_jid
			
		msg = xmpp.Message(to=groupchat)
		ID = 'inv'+str(random.randrange(1, 1000))
		
		msg.setID(ID)
		x=xmpp.Node('x')
		x.setNamespace('http://jabber.org/protocol/muc#user')
		inv=x.addChild('invite', {'to':jid})
		
		if reason:
			inv.setTagData('reason', reason +' (%s)' % (nick))
		else:
			inv.setTagData('reason', u'Вас приглашает '+nick+'.')
			
		msg.addChild(node=x)
		resp = JCON.send(msg)
		
		if resp == ID:
			reply(type,source,u'Сделано!')
	else:
		reply(type,source,u'А, кого?')

register_command_handler(handler_invite_start, COMM_PREFIX+'invite', ['muc','all','*'], 11, 'Приглашет заданного пользователя в конференцию.', COMM_PREFIX+'invite <ник|JID> [: причина]', [COMM_PREFIX+'invite guy', COMM_PREFIX+'invite guy | Заходи к нам, у нас весело ;)',COMM_PREFIX+'invite guy@jabber.aq',COMM_PREFIX+'invite guy@jabber.aq | Есть дело!'])	