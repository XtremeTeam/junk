#===istalismanplugin===
# -*- coding: utf-8 -*-

#  Talisman plugin
#  vote_plugin.py

#  Initial Copyright © 2002-2005 Mike Mintz <mikemintz@gmail.com>
#  Modifications Copyright © 2007 Als <Als@exploit.in>
#  Modifications Copyright © 2009 wd/lotusfeet <dao/yoga>

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.

#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

POLLINGS = {}

try:	POLLINGS=eval(read_file('dynamic/vote.dat'))
except:	pass

def handler_vote_vote(type, source, parameters):
	global POLLINGS
	jid=get_true_jid(source)
	if POLLINGS.has_key(source[1]):
		if POLLINGS[source[1]]['finished']:
			reply(type, source, u'Голосование было завершено!')
			return
		if not POLLINGS[source[1]]['started']:
			reply(type, source, u'Голосование ещё не запущено!')
			return
		if type=='public' and POLLINGS[source[1]]['options']['closed']==1:
			reply(type, source, u'Голосование закрытое, нужно голосовать у меня в привате!')
			return		
		if type=='private' and POLLINGS[source[1]]['options']['closed']==0:
			reply(type, source, u'Голосование открытое, нужно голосовать в общем чате!')
			return				
		if not jid in POLLINGS[source[1]]['jids']:
			POLLINGS[source[1]]['jids'][jid]={'isnotified': 1, 'isvoted': 0}
		if isadmin(jid) or POLLINGS[source[1]]['jids'][jid]['isvoted']==0:
			if POLLINGS[source[1]]['opinions'].has_key(parameters):
				POLLINGS[source[1]]['opinions'][parameters]['cnt'] += 1
				if POLLINGS[source[1]]['options']['nicks']:
					POLLINGS[source[1]]['opinions'][parameters]['nicks'].add(source[2])
				POLLINGS[source[1]]['jids'][jid]['isvoted']=1
				
				reply(type, source, u'Понял!')
				vote_save(source[1])
			else:
				reply(type, source, u'Нет такого пункта!')
		else:
			reply(type, source, u'Ты уже голосовал!')
	else:
		reply(type, source, u'Сейчас нет никаких голосований!')

def handler_vote_newpoll(type, source, parameters):
	global POLLINGS
	if POLLINGS.has_key(source[1]):
		if not POLLINGS[source[1]]['finished']:
			poll_text = u'ТЕКУЩЕЕ ГОЛОСОВАНИЕ\nСоздатель: '+ POLLINGS[source[1]]['creator']['nick']+u'\nВопрос: '+POLLINGS[source[1]]['question'] + u'\nВарианты ответов:\n'
			for opinion in sorted(POLLINGS[source[1]]['opinions'].keys()):
				poll_text += '\t' + opinion + '. ' + POLLINGS[source[1]]['opinions'][opinion]['opinion'] + '\n'
			poll_text += u'Чтобы проголосовать, напиши номер мнения, например "мнение 1"'
			reply(type, source, poll_text)
			return
	jid=get_true_jid(source[1]+'/'+source[2])
	if POLLINGS.has_key(source[1]):
		del POLLINGS[source[1]]
	if parameters:
		POLLINGS = {source[1]: {'started': False, 'finished': False, 'creator': {'jid': jid, 'nick': source[2]}, 'opinions': {}, 'question': parameters, 'options': {'closed': False, 'nicks': False, 'admedit': False, 'time': {'time': 0, 'start': 0}}, 'tick': None, 'jids':{}}}	
				
		reply(type, source, u'Голосование создано!\nЧтобы добавить пункты напиши "%sitem+ твой_пункт". Удалить - "%sitem- номер пункта".\nОпции голосования - команда "%svote*". Начать голосование - команда "%svote+". Посмотреть текущие результаты - команда "%sopinions". Окончить голосование - команда "%stotal".\nЕсли что-то непонятно, то прочитай хелп по командам из категории "vote"!' % (COMM_PREFIX,COMM_PREFIX,COMM_PREFIX,COMM_PREFIX,COMM_PREFIX,COMM_PREFIX))
		
		vote_save(source[1])
	else:
		reply(type,source,u'Не вижу вопроса голосования!')
			
def handler_vote_pollstart(type, source, parameters):
	global POLLINGS
	if not POLLINGS.has_key(source[1]):
		reply(type,source,u'Cейчас нет никаких голосований!')
		return
	if POLLINGS[source[1]]['started']:
		reply(type, source, u'Голосование уже запущено!')
		return
	if POLLINGS[source[1]]['finished']:
		reply(type, source, u'Голосование было завершено!')
		return	
	if len(POLLINGS[source[1]]['opinions'].keys())==0:
		reply(type, source, u'Голосование не имеет пунктов!')
		return			
	jid=get_true_jid(source[1]+'/'+source[2])
	if POLLINGS[source[1]]['creator']['jid']==jid or POLLINGS[source[1]]['options']['admedit']==1 and has_access(jid,20,source[1]):
		POLLINGS[source[1]]['started']=True
		poll_text = u'НОВОЕ ГОЛОСОВАНИЕ\nСоздатель: '+ POLLINGS[source[1]]['creator']['nick']+u'\nВопрос: '+POLLINGS[source[1]]['question'] + u'\nВарианты ответов:\n'
		for opinion in sorted(POLLINGS[source[1]]['opinions'].keys()):
			poll_text += '\t' + opinion + '. ' + POLLINGS[source[1]]['opinions'][opinion]['opinion'] + '\n'
		poll_text += u'Чтобы проголосовать, напиши номер мнения, например "мнение 1"'
		msg(source[1], poll_text)
		if POLLINGS[source[1]]['options']['time']['time']:
			if POLLINGS[source[1]]['tick']:
				if POLLINGS[source[1]]['tick'].isAlive():	vote_tick(0,source[1])
			vote_tick(POLLINGS[source[1]]['options']['time']['time'],source[1])
			POLLINGS[source[1]]['options']['time']['start']=time.time()
		vote_save(source[1])
	else:
		reply(type, source, u'А вот фиг!')

def handler_vote_pollopinion_add(type, source, parameters):
	if not parameters:
		reply(type, source, u'Иии?')
		return		
	global POLLINGS
	jid=get_true_jid(source[1]+'/'+source[2])
	if POLLINGS.has_key(source[1]):
		if POLLINGS[source[1]]['started']:
			reply(type, source, u'Неприменимо к запущеному голосованию, сначала останови/пересоздай!')
			return		
		if POLLINGS[source[1]]['finished']:
			reply(type, source, u'Неприменимо к оконченному голосованию!')
			return					
		if POLLINGS[source[1]]['creator']['jid']==jid or POLLINGS[source[1]]['options']['admedit']==1 and has_access(jid,20,source[1]):
			kcnt=len(POLLINGS[source[1]]['opinions'].keys())+2
			for x in range(1, kcnt):
				if str(x) in POLLINGS[source[1]]['opinions'].keys():
					continue
				else:
					POLLINGS[source[1]]['opinions'][str(x)]={'opinion': parameters, 'cnt': 0, 'nicks': set()}
					reply(type, source, u'Добавил!')
					vote_save(source[1])
		else:
			reply(type, source, u'А вот фиг!')
	else:
		reply(type, source, u'Сейчас нет никаких голосований!')
		
def handler_vote_pollopinion_del(type, source, parameters):
	if not parameters:
		reply(type, source, u'Иии?')
		return		
	global POLLINGS
	jid=get_true_jid(source[1]+'/'+source[2])
	if POLLINGS.has_key(source[1]):
		if POLLINGS[source[1]]['started']:
			reply(type, source, u'Неприменимо к запущеному голосованию, сначала останови/пересоздай!')
			return		
		if POLLINGS[source[1]]['finished']:
			reply(type, source, u'Неприменимо к оконченному голосованию!')
			return					
		if POLLINGS[source[1]]['creator']['jid']==jid or POLLINGS[source[1]]['options']['admedit']==1 and has_access(jid,20,source[1]):
			try:
				del POLLINGS[source[1]]['opinions'][parameters]
				vote_save(source[1])
				reply(type, source, u'Удалил!')
			except:
				reply(type, source, u'Нет такого пункта!')
		else:
			reply(type, source, u'А вот фиг!')
	else:
		reply(type, source, u'Сейчас нет никаких голосований!')
		
def handler_vote_pollopinions(type, source, parameters):
	global POLLINGS
	jid=get_true_jid(source[1]+'/'+source[2])
	if POLLINGS.has_key(source[1]):
		if POLLINGS[source[1]]['finished']:
			reply(type, source, u'РЕЗУЛЬТАТЫ ГОЛОСОВАНИЯ'+vote_results(source[1]))
			return
		if jid==POLLINGS[source[1]]['creator']['jid'] or POLLINGS[source[1]]['options']['admedit']==1 and has_access(jid,20,source[1]):
			if type=='public':
				reply(type, source, u'Ушли в приват!')
			reply('private', source, u'ТЕКУЩИЕ РЕЗУЛЬТАТЫ ГОЛОСОВАНИЯ'+vote_results(source[1]))
		else:
			reply(type, source, u'Жди окончания голосования! :-P')
	else:
		reply(type, source, u'Cейчас нет никаких голосований!')
		
def handler_vote_polloptions(type, source, parameters):
	global POLLINGS
	jid=get_true_jid(source[1]+'/'+source[2])
	if POLLINGS.has_key(source[1]):
		if POLLINGS[source[1]]['finished']:
			reply(type, source, u'Неприменимо к оконченному голосованию!')
			return	
		closed=POLLINGS[source[1]]['options']['closed']
		nicks=POLLINGS[source[1]]['options']['nicks']
		admedit=POLLINGS[source[1]]['options']['admedit']
		timee=POLLINGS[source[1]]['options']['time']['time']
		timest=POLLINGS[source[1]]['options']['time']['start']
		started=POLLINGS[source[1]]['started']
		if parameters:
			if POLLINGS[source[1]]['creator']['jid']==jid or POLLINGS[source[1]]['options']['admedit']==1 and has_access(jid,20,source[1]):
				parameters=parameters.split()
				if len(parameters)!=2:
					reply(type,source,u'Неверный синтаксис!')
					return
				if parameters[0]=='closed':
					if parameters[1]=='1':
						reply(type,source,u'Приватный режим голосования включен!')
						POLLINGS[source[1]]['options']['closed']=True
					else:
						reply(type,source,u'Приватный режим голосования отключен!')
						POLLINGS[source[1]]['options']['closed']=False
				elif parameters[0]=='nicks':
					if parameters[1]=='1':
						reply(type,source,u'Запись ников включена!')
						POLLINGS[source[1]]['options']['nicks']=True
					else:
						reply(type,source,u'Запись ников отключена!')
						POLLINGS[source[1]]['options']['nicks']=False
				elif parameters[0]=='admedit':
					if parameters[1]=='1':
						reply(type,source,u'Теперь администрация может править голосование!')
						POLLINGS[source[1]]['options']['admedit']=True
					else:
						reply(type,source,u'Теперь администрация не может править голосование!')
						POLLINGS[source[1]]['options']['admedit']=False
				elif parameters[0]=='time':
					if not parameters[1]=='0':
						reply(type,source,u'Время голосования %s.' % timeElapsed(int(parameters[1])))
						POLLINGS[source[1]]['options']['time']['time']=int(parameters[1])
						POLLINGS[source[1]]['options']['time']['start']=time.time()
						if started:
							vote_tick(int(parameters[1]),source[1])
					else:
						reply(type,source,u'Время голосования - до ручного завершения.')
						POLLINGS[source[1]]['options']['time']['time']=0
						if started:
							vote_tick(int(parameters[1]),source[1],False)
				else:
					reply(type,source,u'Неверный синтаксис!')
				vote_save(source[1])
			else:
				reply(type, source, u'А вот фиг!')				
		else:
			rep=u'ПАРАМЕТРЫ ГОЛОСОВАНИЯ:\n'
			if closed:
				rep += u'Голосование проводится приватно, '
			else:
				rep += u'Голосование проводится открыто, '
			if nicks:
				rep += u'Ники отвечающих записываются, '
			else:
				rep += u'Ники отвечающих не записываются, '
			if admedit:
				rep += u'Администрация конференции имеет право редактировать голосование и просматривать его результаты, '
			else:
				rep += u'Администрация конференции не имеет права редактировать голосование и просматривать его результаты, '
			if timee:
				if started:
					rep += u'Голосование будет длиться %s, осталось %s.' % (timeElapsed(timee), timeElapsed(timee-(time.time()-timest)))
				else:
					rep += u'Голосование будет длиться %s.' % timeElapsed(timee)
			else:
				rep += u'Голосование будет длиться до его ручного завершения.'
			reply(type, source, rep)
	else:
		reply(type, source, u'Сейчас нет никаких голосований!')			

def handler_vote_endpoll(type, source, parameters):
	global POLLINGS
	jid=get_true_jid(source[1]+'/'+source[2])
	if POLLINGS.has_key(source[1]):
		if POLLINGS[source[1]]['creator']['jid']==jid or POLLINGS[source[1]]['options']['admedit']==1 and has_access(jid,20,source[1]):
			POLLINGS[source[1]]['finished']=True
			POLLINGS[source[1]]['started']=False
			reply(type, source, u'РЕЗУЛЬТАТЫ ГОЛОСОВАНИЯ'+vote_results(source[1]))
			vote_save(source[1])
		else:
			reply(type, source, u'Ага, щаззз!')
	else:
		reply(type, source, u'Сейчас нет никаких голосований!')

def handler_vote_endpoll_tick(gch):
	global POLLINGS
	POLLINGS[gch]['finished']=True
	POLLINGS[gch]['started']=False
	msg(gch, u'РЕЗУЛЬТАТЫ ГОЛОСОВАНИЯ'+vote_results(gch))
	vote_save(gch)

def handler_vote_join(groupchat, nick, aff, role):
	global POLLINGS
	jid=get_true_jid(groupchat+'/'+nick)
	if POLLINGS.has_key(groupchat):
		if POLLINGS[groupchat]['finished']:
			return	
		if POLLINGS[groupchat]['started']:
			if not jid in POLLINGS[groupchat]['jids'].keys():
				POLLINGS[groupchat]['jids'][jid]={'isnotified': 1, 'isvoted': 0}
				poll_text = u'ТЕКУЩЕЕ ГОЛОСОВАНИЕ\nСоздатель: '+ POLLINGS[groupchat]['creator']['nick']+u'\nВопрос: '+POLLINGS[groupchat]['question'] + u'\nВарианты ответов:\n'
				for opinion in sorted(POLLINGS[groupchat]['opinions'].keys()):
					poll_text += '\t' + opinion + '. ' + POLLINGS[groupchat]['opinions'][opinion]['opinion'] + '\n'
				poll_text += u'Чтобы проголосовать, напиши номер мнения, например "%sopinion 1"' % (COMM_PREFIX)
				msg(groupchat+'/'+nick, poll_text)
				vote_save(groupchat)
			
def handler_vote_stoppoll(type, source, parameters):
	global POLLINGS
	if POLLINGS.has_key(source[1]):
		if POLLINGS[source[1]]['finished']:
			reply(type, source, u'Неприменимо к оконченному голосованию!')
			return	
		jid=get_true_jid(source[1]+'/'+source[2])
		if POLLINGS[source[1]]['creator']['jid']==jid or POLLINGS[source[1]]['options']['admedit']==1 and has_access(jid,20,source[1]):
			started=POLLINGS[source[1]]['started']
			if started:
				POLLINGS[source[1]]['started']=False
				timee=POLLINGS[source[1]]['options']['time']['time']
				timest=POLLINGS[source[1]]['options']['time']['start']
				if POLLINGS[source[1]]['options']['time']['time']:
					vote_tick(0,source[1],False)
					POLLINGS[source[1]]['options']['time']['time']=int(timee-(time.time()-timest))
				reply(type, source, u'Голосование приостановлено!')
				vote_save(source[1])
			else:
				reply(type, source, u'Голосование уже приостановлено!')
		else:
			reply(type, source, u'Ага, щаззз!')
			return
	else:
		reply(type, source, u'Сейчас нет никаких голосований!')
			
def vote_tick(timee,gch,start=True):
	global POLLINGS
	if start:
		if timee:
			if POLLINGS[gch]['tick']:
				if POLLINGS[gch]['tick'].isAlive():	POLLINGS[gch]['tick'].cancel()
			POLLINGS[gch]['tick']=threading.Timer(timee, handler_vote_endpoll_tick,(gch,))
			try:
				POLLINGS[gch]['tick'].start()
			except RuntimeError:
				pass
		else:
			try:
				POLLINGS[gch]['tick'].start()
			except RuntimeError:
				pass
	else:
		POLLINGS[gch]['tick'].cancel()
	vote_save(gch)
		
def vote_save(gch):
	global POLLINGS
	DBPATH='dynamic/vote.dat'
	if check_file(file='vote.dat'):
		write_file(DBPATH, str(POLLINGS))
	else:
		print 'Error saving vote for',gch
		
def vote_results(gch):
	global POLLINGS
	answ,cnt,allv=[],0,0
	poll_text = u'\nСоздатель: '+ POLLINGS[gch]['creator']['nick']+u'\nВопрос: '+POLLINGS[gch]['question'] + u'\nИтоги:\n'
	for opinion in POLLINGS[gch]['opinions'].keys():
		if POLLINGS[gch]['options']['nicks']:
			answ.append([POLLINGS[gch]['opinions'][opinion]['cnt'], opinion+'. '+POLLINGS[gch]['opinions'][opinion]['opinion'], u', '.join(sorted(POLLINGS[gch]['opinions'][opinion]['nicks']))])
		else:
			answ.append([POLLINGS[gch]['opinions'][opinion]['cnt'], opinion+'. '+POLLINGS[gch]['opinions'][opinion]['opinion']])
	for opinion in sorted(answ,lambda x,y: int(x[0]) - int(y[0]),reverse=True):
		cnt+=1
		if len(opinion)==3:
			poll_text += u'•\t'+str(cnt)+u' место и '+str(opinion[0])+u' голосов\n\tВопрос: '+opinion[1]+u'\n\tТак решили: '+opinion[2]+u'\n'
			allv+=opinion[0]
		else:
			poll_text += u'•\t'+str(cnt)+u' место и '+str(opinion[0])+u' голосов\n\tВопрос: '+opinion[1]+u'\n'
			allv+=opinion[0]
	poll_text += u'Всего '+str(allv)+u' голосов.'
	return poll_text

register_command_handler(handler_vote_polloptions, COMM_PREFIX+'vote*', ['vote','muc','all','*'], 10, 'Управление опциями голосования. Всего 4 опции:\n1) closed - определяет, будет ли голосование открытым (только в общем чате) или закрытым (только приват)\n2) nicks - определяет, будут ли записывать ники голосующих, для последующей их выдачи вместе с результатами голосования\n3) admedit - определяет, будет ли администрация конференции иметь возможность редактировать голосование\n4) time - для определения времени (в секундах) в течении которого будет длиться голосование. 0 - ручная остановка',COMM_PREFIX+'vote* <опция> <состояние>', [COMM_PREFIX+'vote* nicks 1',COMM_PREFIX+'vote* time 600'])
register_command_handler(handler_vote_stoppoll, COMM_PREFIX+'vote-', ['vote','muc','all','*'], 11, 'Приостанавливает голосование, все данные сохраняются до продолжения голосования.', 'vote-', ['vote-'])
register_command_handler(handler_vote_pollstart, COMM_PREFIX+'vote+', ['vote','muc','all','*'], 11, 'Возобновляет приостановленое голосование.', COMM_PREFIX+'vote+', [COMM_PREFIX+'vote+'])
register_command_handler(handler_vote_vote, COMM_PREFIX+'opinion', ['vote','muc','all','*'], 10, 'Для подачи мнения в текущем голосовании.', COMM_PREFIX+'opinion <мнение>', [COMM_PREFIX+'opinion да'])
register_command_handler(handler_vote_pollopinions, COMM_PREFIX+'opinions', ['vote','muc','all','*'], 11, 'Отдаёт текущие результаты голосования в приват, не завершая голосования при этом.', COMM_PREFIX+'opinions', [COMM_PREFIX+'opinions'])
register_command_handler(handler_vote_newpoll, COMM_PREFIX+'vote', ['vote','muc','all','*'], 11, 'Создаёт новое голосование или отправляет готовое голосование в текущий чат, если даны мнения.', COMM_PREFIX+'vote [вопрос]', [COMM_PREFIX+'vote винды - сакс!', COMM_PREFIX+'vote'])
register_command_handler(handler_vote_pollopinion_add, COMM_PREFIX+'item+', ['vote','muc','all','*'], 11, 'Добавляет пункт (1!) к текущему голосованию.', COMM_PREFIX+'item+ <твой_пункт>', ['item+ да'])
register_command_handler(handler_vote_pollopinion_del, COMM_PREFIX+'item-', ['vote','muc','all','*'], 11, 'Удаляет пункт из голосования. Пункт указывается его номером.', COMM_PREFIX+'item- <номер_пункта>', [COMM_PREFIX+'item- 5'])
register_command_handler(handler_vote_endpoll, COMM_PREFIX+'total', ['vote','muc','all','*'], 11, 'Завершает голование и показывает его результаты.', COMM_PREFIX+'total', [COMM_PREFIX+'total'])
	
register_join_handler(handler_vote_join)