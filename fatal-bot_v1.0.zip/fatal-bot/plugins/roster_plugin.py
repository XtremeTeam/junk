#===isfatalplugin===
# -*- coding: utf-8 -*-

#  fatal plugin
#  roster_plugin.py

#  Copyright © 1998-2009 wd/lotusfeet <dao/yoga>

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.

#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

MSUBS_QUERY = 0

def check_jid(jid):
	parse_jid = jid.split('@')
	
	if len(parse_jid) == 2:
		if parse_jid[0] and parse_jid[1]:
			if parse_jid[1].count('.') >= 1 and parse_jid[1].count('.') <= 3:
				return True
			else:
				return False	
		else:
			return False
	else:
		return False

def parse_subs_par(params):
	jid = ''
	name = ''
	access = ''
	
	if params:
		spltdp = params.strip().split(':',1)
		
		if len(spltdp) == 1:
			spltdp = spltdp[0].strip().split(' ',1)
			
			if len(spltdp) == 1:
				jid = spltdp[0]
			elif len(spltdp) == 2:
				jid = spltdp[0]
				name = spltdp[1]
		elif len(spltdp) == 2:
			jid_name = spltdp[0].strip()
			access = spltdp[1]
			spltdp = jid_name.split(' ',1)
			
			if len(spltdp) == 1:
				jid = spltdp[0]
			elif len(spltdp) == 2:
				jid = spltdp[0]
				name = spltdp[1]

	return (jid.strip(),name.strip(),access.strip())
		
def handler_subscribe(type, source, parameters):
	cont_jids = ROSTER.getItems()
	
	global MANUAL_SUBSCRIBE
	global GTEMP_SUBS_NAME
	global MSUBS_QUERY
	MANUAL_SUBSCRIBE = 1
	MSUBS_QUERY = 1
	
	if parameters:
		parsed_par = parse_subs_par(parameters)
		jid = parsed_par[0]
		name = parsed_par[1]
		access = parsed_par[2]
		
		if check_jid(jid):
			if jid in cont_jids:
				gsubs = ROSTER.getSubscription(jid)
				
				if gsubs != 'both':
					if not name:
						name = jid.split('@',1)[0]
					
					GTEMP_SUBS_NAME = name
					ROSTER.Subscribe(jid)
					
					if access and access.isdigit():
						change_access_perm_glob(jid, int(access))
					else:
						change_access_perm_glob(jid, 11)
						
					rep = u'Контакту %s послан запрос на авторизацию!' % (jid)
					reply(type, source, rep)
				else:
					cont_groups = ROSTER.getGroups(jid)
					
					if not 'bot-users' in cont_groups:
						old_name = ROSTER.getName(jid)
						
						if old_name:
							name = old_name
						elif not name:
							name = jid.split('@',1)[0]
							
						GTEMP_SUBS_NAME = name	
						ROSTER.setItem(jid,GTEMP_SUBS_NAME,['bot-users'])
						
						if access and access.isdigit():
							change_access_perm_glob(jid, int(access))
						else:
							change_access_perm_glob(jid, 11)
						
						rep = u'Контакт %s уже в ростере бота, но перенесен в группу bot-users!' % (jid)
						reply(type, source, rep)
					else:
						rep = u'Контакт %s уже в ростере бота и авторизован!' % (jid)
						reply(type, source, rep)
			else:
				if not name:
					name = jid.split('@',1)[0]
				
				if access and access.isdigit():
					change_access_perm_glob(jid, int(access))
				else:
					change_access_perm_glob(jid, 11)
				
				GTEMP_SUBS_NAME = name
				ROSTER.Subscribe(jid)
							
				rep = u'Контакт %s добавлен в ростер бота и ему отправлен запрос на авторизацию!' % (jid)
				reply(type, source, rep)
		else:
			reply(type, source, u'Неверный синтаксис!')
	else:
		reply(type, source, u'Неверный синтаксис!')
		
def handler_usubscribe(type, source, parameters):
	cont_jids = ROSTER.getItems()
	
	global MANUAL_USUBSCRIBE
	MANUAL_USUBSCRIBE = 1
	
	if parameters:
		if check_jid(parameters):
			ajid = parameters
			
			if ajid in cont_jids:
				gsubs = ROSTER.getSubscription(ajid)			
				
				if gsubs == 'both':
					if 'bot-users' in ROSTER.getGroups(ajid):
						change_access_perm_glob(ajid)
					
					ROSTER.Unsubscribe(ajid)
					ROSTER.delItem(ajid)
				else:
					ROSTER.delItem(ajid)
					
				rep = u'Подписка и контакт %s удалены из ростера бота!' % (ajid)
				reply(type, source, rep)	
			else:
				rep = u'Контакт %s не найден в ростере бота!' % (ajid)
				reply(type, source, rep)
		else:
			reply(type, source, u'Неверный синтаксис!')
	else:
		reply(type, source, u'Неверный синтаксис!')		
		
register_command_handler(handler_subscribe, COMM_PREFIX+'subscribe', ['roster','superadmin','all','*'], 100, 'Позволяет добавить контакт в ростер бота и посылает этому контакту запрос на авторизацию.', COMM_PREFIX+'subscribe <jid [name][:access]>', [COMM_PREFIX+'subscribe guy@jabber.aq',COMM_PREFIX+'subscribe guy@jabber.aq: 20',COMM_PREFIX+'subscribe guy@jabber.aq Friend',COMM_PREFIX+'subscribe guy@jabber.aq Friend: 80'])
register_command_handler(handler_usubscribe, COMM_PREFIX+'usubscribe', ['roster','superadmin','all','*'], 100, 'Позволяет удалить контакт и подписку из ростера бота.', COMM_PREFIX+'usubscribe <jid>', [COMM_PREFIX+'usubscribe guy@jabber.aq'])