#===istalismanplugin===
# -*- coding: utf-8 -*-

#  Talisman plugin
#  delirium_plugin.py

#  Initial Copyright © 2007 Als <Als@exploit.in>
#  Modifications Copyright © 2009 wd/lotusfeet <dao/yoga>

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.

#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

poke_nicks={}

def handler_poke(type, source, parameters):
	if type=='private':
		reply(type,source,u':-P')
		return
	groupchat = source[1]
	if parameters:
		if parameters==u'last10':
			cnt=0
			rep=''
			nicks = set()
			for x in [poke_nicks[source[1]] for x in poke_nicks]:
				nicks = nicks | set(x)
			for x in nicks:
				cnt=cnt+1
				rep += str(cnt)+u') '+x+u'\n'
			reply('private',source,rep[:-1])
			return
		if not poke_nicks.has_key(source[1]):
			poke_nicks[source[1]]=source[1]
			poke_nicks[source[1]]=[]
		if len(poke_nicks[source[1]])==10:
			poke_nicks[source[1]]=[]
		else:
			poke_nicks[source[1]].append(source[2])
		if not parameters == get_bot_nick(source[1]):
			if parameters in GROUPCHATS[source[1]]:
				pokes=[]
				pokes.extend(poke_work(source[1]))
				pokes.extend(eval(read_file('static/delirium.txt'))['poke'])
				rep = random.choice(pokes)
				msg(source[1],u'/me '+rep % parameters)
			else:
				reply(type, source, u'А он тут? :-O')
		else:
			reply(type, source, u'Шибко умный, да? ]:->')	
	else:
		reply(type, source, u'Мазохист? :D')
		
def handler_poke_add(type, source, parameters):
	if not parameters:
		reply(type, source, u'Иии?')
	if not parameters.count('%s'):
		reply(type, source, u'Не вижу %s.')
		return
	res=poke_work(source[1],1,parameters)
	if res:
		reply(type, source, u'Добавлено.')
	else:
		reply(type, source, u'Больше нельзя.')
		
def handler_poke_del(type, source, parameters):
	if not parameters:
		reply(type, source, u'Иии?')
	if parameters=='*':
		parameters='0'
	else:
		try:
			int(parameters)
		except:
			reply(type,source,u'Неверный синтаксис!')
	res=poke_work(source[1],2,parameters)
	if res:
		reply(type, source, u'Удалено!')
	else:
		reply(type, source, u'Такой нет!')
		
def handler_poke_list(type, source, parameters):
	rep,res=u'',poke_work(source[1],3)
	if res:
		res=sorted(res.items(),lambda x,y: int(x[0]) - int(y[0]))
		for num,phrase in res:
			rep+=num+u') '+phrase+u'\n'
		reply(type,source,rep.strip())
	else:
		reply(type,source,u'Нет пользовательских фраз!')
		
def handler_test(type, source, parameters):
	reply(type,source,u'Пройден успешно!')
	
def handler_clean_conf(type, source, parameters):
	if GROUPCHATS.has_key(source[1]):
		for x in range(1, 21):
			msg(source[1], '')
			time.sleep(1.3)
		reply('private',source,u'Done!')
		
def handler_afools_control(type, source, parameters):
	if parameters:
		try:
			int(parameters)
		except:
			reply(type,source,u'Неверный синтаксис!')
		if int(parameters)>1:
			reply(type,source,u'Неверный синтаксис!')
		if parameters=="1":
			GCHCFGS[source[1]]['afools']=1
			reply(type,source,u'Шуточки включены!')
		else:
			GCHCFGS[source[1]]['afools']=0
			reply(type,source,u'Шуточки отключены!')
		write_file('dynamic/'+source[1]+'/config.cfg', str(GCHCFGS[source[1]]))
	else:
		if GCHCFGS[source[1]]['afools']==1:
			reply(type,source,u'Здесь шуточки включены!')
		else:
			reply(type,source,u'Здесь шуточки отключены!')
			
def get_afools_state(gch):
	if not 'afools' in GCHCFGS[gch]:
		GCHCFGS[gch]['afools']=0
		
def poke_work(gch,action=None,phrase=None):
	DBPATH='dynamic/'+gch+'/delirium.txt'
	if check_file(gch,'delirium.txt'):
		pokedb = eval(read_file(DBPATH))
		if action==1:
			for x in range(1, 21):
				if str(x) in pokedb.keys():
					continue
				else:
					pokedb[str(x)]=phrase
					write_file(DBPATH, str(pokedb))
					return True
			return False
		elif action==2:
			if phrase=='0':
				pokedb.clear()
				write_file(DBPATH, str(pokedb))
				return True
			else:
				try:
					del pokedb[phrase]
					write_file(DBPATH, str(pokedb))
					return True
				except:
					return False
		elif action==3:
			return pokedb
		else:
			return pokedb.values()
	else:
		return None
		
def remix_string(parameters):
	remixed=[]
	for word in parameters.split():
		tmp=[]
		if len(word)<=1:
			remixed.append(word)
			continue
		elif len(word)==2:
			tmp=list(word)
			random.shuffle(tmp)
			remixed.append(u''.join(tmp))
		elif len(word)==3:
			tmp1=list(word[1:])
			tmp2=list(word[:-1])
			tmp=random.choice([tmp1,tmp2])
			if tmp==tmp1:
				random.shuffle(tmp)
				remixed.append(word[0]+u''.join(tmp))
			else:
				random.shuffle(tmp)
				remixed.append(u''.join(tmp)+word[-1])					
		elif len(word)>=4:
			tmp=list(word[1:-1])
			random.shuffle(tmp)
			remixed.append(word[0]+u''.join(tmp)+word[-1])
	return u' '.join(remixed)	

register_command_handler(handler_poke, COMM_PREFIX+'poke', ['fun','all','*','poke'], 10, 'Тыкает юзера. Заставляет его обратить внимание на вас/на чат, специально для слоупоков.\nlast10 вместо ника покажет список ников, которые тыкали последними.', COMM_PREFIX+'poke <nick>|<param>', [COMM_PREFIX+'poke qwerty',COMM_PREFIX+'poke + пришиб %s',COMM_PREFIX+'poke - 2',COMM_PREFIX+'poke *'])
register_command_handler(handler_poke_add, COMM_PREFIX+'poke+', ['fun','all','*','poke'], 20, 'Добавить пользовательскую фразу. Переменная %s во фразе обозначает место для вставки ника (обязательный параметр). Фраза должна быть написана от третьего лица, т.к. будет использоваться в виде "/me ваша фраза". max кол-во пользовательских фраз - 20.', COMM_PREFIX+'poke+ <фраза>', [COMM_PREFIX+'poke+ побил %s'])
register_command_handler(handler_poke_del, COMM_PREFIX+'poke-', ['fun','all','*','poke'], 20, 'Удалить пользовательскую фразу. Пишем номер удаляемой фразы и она удаляется навсегда. Пронумерованный список выдаёт команда "%spoke*". Удалить все фразы можно с помощью символа "*" вместо номера фразы.' % (COMM_PREFIX), COMM_PREFIX+'poke- <номер>', [COMM_PREFIX+'poke- 5',COMM_PREFIX+'poke- *'])
register_command_handler(handler_poke_list, COMM_PREFIX+'poke*', ['fun','all','*','poke'], 20, 'Показывает пронумерованный список всех пользовательских фраз.', COMM_PREFIX+'poke*', [COMM_PREFIX+'poke*'])
register_command_handler(handler_test, COMM_PREFIX+'test', ['fun','info','all'], 0, 'Тупо отвечает: Пройден успешно!', COMM_PREFIX+'test', [COMM_PREFIX+'test'])
register_command_handler(handler_clean_conf, COMM_PREFIX+'clean', ['fun','muc','all','*'], 15, 'Очищает конференцию (втихую).', COMM_PREFIX+'clean', [COMM_PREFIX+'clean'])
register_command_handler(handler_afools_control, COMM_PREFIX+'afools', ['fun','muc','all','*'], 30, 'Включает и выключает шуточки бота, которыми он порою подменяет (саму команду он всегда исполняет!) стандартный ответ команды.', COMM_PREFIX+'afools <1|0>', [COMM_PREFIX+'afools 1',COMM_PREFIX+'afools 0'])

register_stage1_init(get_afools_state)