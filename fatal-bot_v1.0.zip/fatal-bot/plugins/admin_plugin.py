#===istalismanplugin===
# -*- coding: utf-8 -*-

#  Talisman plugin
#  admin_plugin.py

#  Initial Copyright © 2002-2005 Mike Mintz <mikemintz@gmail.com>
#  Modifications Copyright © 2007 Als <Als@exploit.in>
#  Modifications and New features Copyright © 2009 wd/lotusfeet <dao/yoga>

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.

#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

def popups_check(gch):
	DBPATH='dynamic/'+gch+'/config.cfg'
	if GCHCFGS[gch].has_key('popups'):
		if GCHCFGS[gch]['popups'] == 1:
			return 1
		else:
			return 0
	else:
		GCHCFGS[gch]['popups']=1
		write_file(DBPATH,str(GCHCFGS[gch]))
		return 1

def handler_remote(type, source, parameters):	
	groupchat = source[1]
	nick = source[2]
	
	groupchats = GROUPCHATS.keys()
	groupchats.sort()

	if parameters:
		spltdp = parameters.split(' ', 2)
		dest_gch = spltdp[0]
		
		if len(spltdp) >= 2:
			dest_comm = spltdp[1]
		else:
			reply(type, source, u'Неверный синтаксис!')
			return
		
		dest_params = ''
		
		if dest_gch.isdigit():
			if int(dest_gch) <= len(groupchats) and int(dest_gch) != 0:
				dest_gch = groupchats[int(dest_gch)-1]
			else:
				reply(type, source, u'Конференция не существует!')
				return
		else:
			if not dest_gch in groupchats:
				reply(type, source, u'Конференция не существует!')
				return
				
		if len(spltdp) >= 3:
			dest_params = spltdp[2]
		
		bot_nick = get_bot_nick(dest_gch)
		
		dest_source = [groupchat+'/'+nick,dest_gch,bot_nick]
		
		if COMMAND_HANDLERS.has_key(COMM_PREFIX+dest_comm.lower()):
			comm_hnd = COMMAND_HANDLERS[COMM_PREFIX+dest_comm.lower()]
		elif MACROS.macrolist[dest_gch].has_key(dest_comm.lower()):
			exp_alias = MACROS.expand(dest_comm.lower(), dest_source)
			
			spl_comm_par = exp_alias.split(' ',1)
			dest_comm = spl_comm_par[0]
			
			if len(spl_comm_par) >= 2:
				alias_par = spl_comm_par[1]
				dest_params = alias_par+' '+dest_params
				dest_params = dest_params.strip()
			
			if COMMAND_HANDLERS.has_key(dest_comm.lower()):
				comm_hnd = COMMAND_HANDLERS[dest_comm.lower()]
			else:
				reply(type, source, u'Неизвестная команда!')
				return
		elif MACROS.gmacrolist.has_key(dest_comm.lower()):
			exp_alias = MACROS.expand(dest_comm.lower(), dest_source)
			
			spl_comm_par = exp_alias.split(' ',1)
			dest_comm = spl_comm_par[0]
			
			if len(spl_comm_par) >= 2:
				alias_par = spl_comm_par[1]
				dest_params = alias_par+' '+dest_params
				dest_params = dest_params.strip()
			
			if COMMAND_HANDLERS.has_key(dest_comm.lower()):
				comm_hnd = COMMAND_HANDLERS[dest_comm.lower()]
			else:
				reply(type, source, u'Неизвестная команда!')
				return
		else:
			reply(type, source, u'Неизвестная команда!')
			return
		
		if type == 'public':
			reply(type, source, u'Смотри в привате!')
			
		comm_hnd('private',dest_source,dest_params)
	else:
		gchli = [u'%s) %s' % (groupchats.index(li)+1,li) for li in groupchats]
		
		if gchli:
			rep = u'Доступные конференции:\n%s' % ('\n'.join(gchli))
		else:
			rep = u'Нет доступных конференций!'
			
		reply(type, source, rep)

def handler_redirect(type, source, parameters):	
	groupchat = source[1]
	nick = source[2]
	
	if parameters:
		if ':' in parameters:
			spltdp = parameters.split(':', 1)
			dest_nick = spltdp[0]
			
			if len(spltdp) >= 2:
				mess = spltdp[1]
				comm_par = spltdp[1].strip()
				comm_par = comm_par.split(' ',1)
				comm = comm_par[0].strip()
				params = ''
				
				if len(comm_par) >= 2:
					params = comm_par[1].strip()
			else:
				reply(type, source, u'Неверный синтаксис!')
				return
			
			bot_nick = get_bot_nick(groupchat)
			
			dest_source = [groupchat+'/'+dest_nick,groupchat,bot_nick]
			
			if COMMAND_HANDLERS.has_key(COMM_PREFIX+comm.lower()):
				comm_hnd = COMMAND_HANDLERS[COMM_PREFIX+comm.lower()]
			elif MACROS.macrolist[groupchat].has_key(comm.lower()):
				exp_alias = MACROS.expand(comm.lower(), dest_source)
				
				spl_comm_par = exp_alias.split(' ',1)
				comm = spl_comm_par[0]
				
				if len(spl_comm_par) >= 2:
					alias_par = spl_comm_par[1]
					params = alias_par+' '+params
					params = params.strip()
				
				if COMMAND_HANDLERS.has_key(comm.lower()):
					comm_hnd = COMMAND_HANDLERS[comm.lower()]
				else:
					reply(type, source, u'Отправлено!')
					reply('private', [groupchat+'/'+dest_nick,groupchat,dest_nick], mess)
					return
			elif MACROS.gmacrolist.has_key(comm.lower()):
				exp_alias = MACROS.expand(comm.lower(), dest_source)
				
				spl_comm_par = exp_alias.split(' ',1)
				comm = spl_comm_par[0]
				
				if len(spl_comm_par) >= 2:
					alias_par = spl_comm_par[1]
					params = alias_par+' '+params
					params = params.strip()
				
				if COMMAND_HANDLERS.has_key(comm.lower()):
					comm_hnd = COMMAND_HANDLERS[comm.lower()]
				else:
					reply('private', [groupchat+'/'+dest_nick,groupchat,dest_nick], mess)
					reply(type, source, u'Отправлено!')
					return
			else:
				reply('private', [groupchat+'/'+dest_nick,groupchat,dest_nick], mess)
				reply(type, source, u'Отправлено!')
				return
			
			comm_hnd('private',dest_source,params)
			reply(type, source, u'Отправлено!')
		else:
			reply(type, source, u'Неверный синтаксис!')
	else:
		reply(type, source, u'Неверный синтаксис!')
	
def handler_set_nick(type, source, parameters):
	if parameters:
		groupchat=source[1]
		nick=parameters
		join_groupchat(groupchat,nick)
		reply(type, source, u'Запомнил!')
	else:
		reply(type, source, u'Прочитай помощь по команде!')
					
def handler_admin_join(type, source, parameters):
	if not source[1] in GROUPCHATS:
		source[2]=source[1].split('@')[0]
	if parameters:
		passw=''
		args = parameters.split()
		if not args[0].count('@') or not args[0].count('.')>=1:
			reply(type, source, u'Прочитай помощь по команде!')
			return
		if len(args)>1:
			groupchat = args[0]
			passw = string.split(args[1], 'pass=', 1)
			if not passw[0]:
				bot_nick = ' '.join(args[2:])
			else:
				bot_nick = ' '.join(args[1:])
		else:
			groupchat = parameters
			bot_nick = ''
		get_gch_cfg(groupchat)
		for process in STAGE1_INIT:
			with smph:
				INFO['thr'] += 1
				try:
					threading.Thread(None,process,'atjoin_init'+str(INFO['thr']),(groupchat,)).start()
				except RuntimeError:
					pass
		DBPATH='dynamic/'+groupchat+'/config.cfg'
		write_file(DBPATH, str(GCHCFGS[groupchat]))
		if not passw:
			if not bot_nick:
				join_groupchat(groupchat, DEFAULT_NICK)
			else:
				join_groupchat(groupchat, bot_nick)
		else:
			if not bot_nick:
				join_groupchat(groupchat, DEFAULT_NICK, passw)
			else:
				join_groupchat(groupchat, bot_nick, passw)
		MACROS.load(groupchat)
		if bot_nick:
			reply(type, source, u'Я зашёл в ' + groupchat+u' c ником '+bot_nick+'.')
		else:
			reply(type, source, u'Я зашёл в ' + groupchat+u' c ником '+DEFAULT_NICK+'.')
		if popups_check(groupchat):
			msg(groupchat, u'Меня привёл '+source[2]+'.')
	else:
		reply(type, source, u'Прочитай помощь по команде!')

def handler_admin_leave(type, source, parameters):
	if not source[1] in GROUPCHATS:
		source[2]=source[1].split('@')[0]
	args = parameters.split()
	if len(args)>1:
		level=int(user_level(source[1]+'/'+source[2], source[1]))
		if level<40 and args[0]!=source[1]:
			reply(type, source, u'Ага, щаззз!')
			return
		reason = ' '.join(args[1:]).strip()
		if not GROUPCHATS.has_key(args[0]):
			reply(type, source, u'А меня там нету!')
			return
		groupchat = args[0]
	elif len(args)==1:
		level=int(user_level(source[1]+'/'+source[2], source[1]))
		if level<40 and args[0]!=source[1]:
			reply(type, source, u'А вот фиг!')
			return
		if not GROUPCHATS.has_key(args[0]):
			reply(type, source, u'А меня там нету!')
			return
		reason = ''
		groupchat = args[0]
	else:
		if not source[1] in GROUPCHATS:
			reply(type, source, u'Это возможно только в конференции!')
			return
		groupchat = source[1]
		reason = ''
	if popups_check(groupchat):
		if reason:
			msg(groupchat, u'Меня уводит '+source[2]+u' по причине:\n'+reason)
		else:
			msg(groupchat, u'Меня уводит '+source[2]+'.')
	if reason:
		leave_groupchat(groupchat, u'Меня уводит '+source[2]+u' по причине:\n'+reason)
	else:
		leave_groupchat(groupchat,u'Меня уводит '+source[2]+'.')
	reply(type, source, u'Я ушёл из ' + groupchat+'.')


def handler_admin_msg(type, source, parameters):
	if not parameters:
		reply(type, source, u'Прочитай помощь по команде!')
		return
	msg(string.split(parameters)[0], string.join(string.split(parameters)[1:]))
	reply(type, source, u'Сообщение отправлено!')
	
def handler_glob_msg_help(type, source, parameters):
	total = '0'
	totalblock='0'
	if GROUPCHATS:
		gch=GROUPCHATS.keys()
		for x in gch:
			if popups_check(x):
				msg(x, u'Новости от '+source[2]+u':\n'+parameters+u'\nНапоминаю, что как всегда всю помощь можно получить написав "%shelp".\nО всех глюках, ошибках, ляпях, а также предложения и конструктивную критику прошу направлять мне таким образом: пишем "%stell botadmin и тут ваше сообщение", естественно без кавычек.\nСПАСИБО ЗА ВНИМАНИЕ!' % (COMM_PREFIX,COMM_PREFIX))
				
				totalblock = int(totalblock) + 1
			total = int(total) + 1
		reply(type, source, 'Сообщение ушло в '+str(totalblock)+' конференций (из '+str(total)+').')
	else:
		reply(type, source, u'Прочитай помощь по команде!')
		
def handler_glob_msg(type, source, parameters):
	total = '0'
	totalblock='0'
	if parameters:
		if GROUPCHATS:
			gch=GROUPCHATS.keys()
			for x in gch:
				if popups_check(x):
					msg(x, u'Новости от '+source[2]+':\n'+parameters)
					totalblock = int(totalblock) + 1
				total = int(total) + 1
			reply(type, source, 'Сообщение ушло в '+str(totalblock)+' конференций (из '+str(total)+').')
	else:
		reply(type, source, u'Прочитай помощь по команде!')
	
def handler_admin_say(type, source, parameters):
	if parameters:
		args=parameters.split()[0]
		msg(source[1], parameters)
	else:
		reply(type, source, u'Прочитай помощь по команде!')

def handler_admin_restart(type, source, parameters):
	if not source[1] in GROUPCHATS:
		source[2]=source[1].split('@')[0]
	if parameters:
		reason = parameters
	else:
		reason = ''
	gch=[]
	if GROUPCHATS:
		gch=GROUPCHATS.keys()
	if reason:
		for x in gch:
			if popups_check(x):
				msg(x, u'Меня перезагружает '+source[2]+u' по причине:\n'+reason)
	else:
		for x in gch:
			if popups_check(x):
				msg(x, u'Меня перезагружает '+source[2]+'.')
	prs=xmpp.Presence(typ='unavailable')
	if reason:
		prs.setStatus(source[2]+u': Рестарт --> '+reason)
	else:
		prs.setStatus(source[2]+u': Рестарт.')
	JCON.send(prs)
	time.sleep(1)
	JCON.disconnect()

def handler_admin_exit(type, source, parameters):
	if not source[1] in GROUPCHATS:
		source[2]=source[1].split('@')[0]
	if parameters:
		reason = parameters
	else:
		reason = ''
	gch=[]
	if GROUPCHATS:
		gch=GROUPCHATS.keys()
	if reason:
		for x in gch:
			if popups_check(x):
				msg(x, u'Меня выключает '+source[2]+u' по причине:\n'+reason)
	else:
		for x in gch:
			if popups_check(x):
				msg(x, u'Меня выключает '+source[2]+'.')
	prs=xmpp.Presence(typ='unavailable')
	if reason:
		prs.setStatus(source[2]+u': Выключаюсь --> '+reason)
	else:
		prs.setStatus(source[2]+u': Выключаюсь.')
	JCON.send(prs)
	time.sleep(2)
	os.abort()
	
def handler_popups_onoff(type, source, parameters):
	if not source[1] in GROUPCHATS:
		reply(type, source, u'Это возможно только в конференции!')
		return
	if parameters:
		try:
			parameters=int(parameters.strip())
		except:
			reply(type,source,u'Прочитай помощь по команде!')
			return		
		DBPATH='dynamic/'+source[1]+'/config.cfg'
		if parameters==1:
			GCHCFGS[source[1]]['popups']=1
			reply(type,source,u'Глобальные оповещения включены!')
		else:
			GCHCFGS[source[1]]['popups']=0
			reply(type,source,u'Глобальные оповещения выключены!')
		write_file(DBPATH,str(GCHCFGS[source[1]]))
	else:
		ison=GCHCFGS[source[1]]['popups']
		if ison==1:
			reply(type,source,u'Здесь глобальные оповещения включены!')
		else:
			reply(type,source,u'Здесь глобальные оповещения выключены!')
			
def handler_botautoaway_onoff(type, source, parameters):
	if not source[1] in GROUPCHATS:
		reply(type, source, u'Это возможно только в конференции!')
		return
	if parameters:
		try:
			parameters=int(parameters.strip())
		except:
			reply(type,source,u'Прочитай помощь по команде!')
			return		
		DBPATH='dynamic/'+source[1]+'/config.cfg'
		if parameters==1:
			GCHCFGS[source[1]]['autoaway']=1
			reply(type,source,u'Автоотсутствие включено!')
		else:
			GCHCFGS[source[1]]['autoaway']=0
			reply(type,source,u'Автоотсутствие отключено!')
		get_autoaway_state(source[1])
		write_file(DBPATH,str(GCHCFGS[source[1]]))
	else:
		ison=GCHCFGS[source[1]]['autoaway']
		if ison==1:
			reply(type,source,u'Здесь автоотсутствие включено!')
		else:
			reply(type,source,u'Здесь автоотсутствие отключено!')	
	
def handler_changebotstatus(type, source, parameters):
	if parameters:
		args,show,status=parameters.split(' ',1),'',''
		if args[0] in ['away','xa','dnd','chat']:
			show=args[0]
		else:
			show=None
			status=parameters
		if not status:
			try:
				status=args[1]
			except:
				status=None
		change_bot_status(source[1],status,show,0)
		GCHCFGS[source[1]]['status']={'status': status, 'show': show}
		reply(type,source, u'Статус установлен.')
	else:
		stmsg=GROUPCHATS[source[1]][get_bot_nick(source[1])]['stmsg']
		status=GROUPCHATS[source[1]][get_bot_nick(source[1])]['status']
		if stmsg:
			reply(type,source, u'Я сейчас '+status+u' ('+stmsg+u').')
		else:
			reply(type,source, u'Я сейчас '+status+'.')
			
def get_autoaway_state(gch):
	if not 'autoaway' in GCHCFGS[gch]:
		GCHCFGS[gch]['autoaway']=1
	if GCHCFGS[gch]['autoaway']:
		LAST['gch'][gch]['autoaway']=0
		LAST['gch'][gch]['thr']=None
		
def set_default_gch_status(gch):
	if isinstance(GCHCFGS[gch].get('status'), str): #temp workaround
		GCHCFGS[gch]['status']={'status': u'Напишите "%shelp" и следуйте указаниям, чтобы понять как со мной работать!' % (COMM_PREFIX), 'show': u''}
	elif not isinstance(GCHCFGS[gch].get('status'), dict):
		GCHCFGS[gch]['status']={'status': u'Напишите "%shelp" и следуйте указаниям, чтобы понять как со мной работать!' % (COMM_PREFIX), 'show': u''}

def handler_delivery(type,source,body):
	sender_jid = source[1]
	
	if GROUPCHATS.has_key(sender_jid):
		return
		
	if ADMINS_DELIVERY:
		if not sender_jid in ADMINS:
			prob_comm = body.split()[0].lower()
			cname = ''
			
			if sender_jid in ROSTER.getItems():
				subs = ROSTER.getSubscription(sender_jid)
				cname = ROSTER.getName(sender_jid)
				
				#if subs != 'both':
				#	return
			#else:
			#	return
			
			if not cname:
				cname = sender_jid
			
			if not prob_comm in COMMANDS and not prob_comm in MACROS.gmacrolist:
				if cname != sender_jid:
					rep = u'Сообщение от %s (%s):\n\n%s' % (cname, sender_jid, body)
				else:
					rep = u'Сообщение от %s:\n\n%s' % (cname, body)
				
				for adli in ADMINS:
					msg(adli,rep)
				
def handler_admin_subscription():
	for adli in ADMINS:
		gsubs = ''
		
		if adli in ROSTER.getItems():
			gsubs = ROSTER.getSubscription(adli)
		
		admin_id = adli.split('@')[0]
		
		if not gsubs:
			ROSTER.setItem(adli,admin_id,['bot-admins'])
			
		if gsubs != 'both':
			ROSTER.Subscribe(adli)
				
register_command_handler(handler_admin_join, COMM_PREFIX+'join', ['superadmin','muc','all','*'], 40, 'Зайти в определённую конференцию. Если она запаролена то пишите пароль сразу после её названия.', COMM_PREFIX+'join <конференция> [pass=пароль] [ник_бота]', [COMM_PREFIX+'join ы@conference.jabber.aq', COMM_PREFIX+'join ы@conference.jabber.aq somebot', COMM_PREFIX+'join ы@conference.jabber.aq pass=1234 somebot'])
register_command_handler(handler_admin_leave, COMM_PREFIX+'leave', ['admin','muc','all','*'], 20, 'Заставляет выйти из текущей или определённой конференции.', COMM_PREFIX+'leave <конференция> [причина]', [COMM_PREFIX+'leave ы@conference.jabber.aq спать', COMM_PREFIX+'leave спать',COMM_PREFIX+'leave'])
register_command_handler(handler_admin_msg, COMM_PREFIX+'message', ['admin','muc','all','*'], 40, 'Отправляет сообщение от имени бота на определённый JID.', COMM_PREFIX+'message <jid> <сообщение>', [COMM_PREFIX+'message guy@jabber.aq здорово чувак!'])
register_command_handler(handler_admin_say, COMM_PREFIX+'say', ['admin','muc','all','*'], 20, 'Говорить через бота в конференции.', COMM_PREFIX+'say <сообщение>', [COMM_PREFIX+'say салют пиплы'])
register_command_handler(handler_admin_restart, COMM_PREFIX+'restart', ['superadmin','all','*'], 100, 'Перезапускает бота.', COMM_PREFIX+'restart [причина]', [COMM_PREFIX+'restart',COMM_PREFIX+'restart ы!'])
register_command_handler(handler_admin_exit, COMM_PREFIX+'halt', ['superadmin','all','*'], 100, 'Остановка и полный выход бота.', COMM_PREFIX+'halt [причина]', [COMM_PREFIX+'halt',COMM_PREFIX+'halt глюки'])
register_command_handler(handler_glob_msg, COMM_PREFIX+'globmsg', ['superadmin','muc','all','*'], 100, 'Разослать сообщение по всем конференциям, в которых сидит бот.', COMM_PREFIX+'globmsg [сообщение]', [COMM_PREFIX+'globmsg всем привет!'])
register_command_handler(handler_glob_msg_help, COMM_PREFIX+'hglobmsg', ['superadmin','muc','all','*'], 100, 'Разослать сообщение по всем конфам, в которых сидит бот. Сообщение будет содержать в себе предустановленный заголовок с короткой справкой об испольовании бота.', COMM_PREFIX+'hglobmsg [сообщение]', [COMM_PREFIX+'hglobmsg всем привет!'])
register_command_handler(handler_popups_onoff, COMM_PREFIX+'popups', ['admin','muc','all','*'], 30, 'Отключает (0) или включает (1) сообщения о входах/выходах, рестартах/выключениях, а также глобальные новости. Без параметра покажет текущее состояние.', COMM_PREFIX+'popups [1|0]', [COMM_PREFIX+'popups 1',COMM_PREFIX+'popups'])
register_command_handler(handler_botautoaway_onoff, COMM_PREFIX+'autoaway', ['admin','muc','all','*'], 30, 'Отключает (0) или включает (1) автосмену статуса бота на away при отсутствии команд в течении 10 минут. Без параметра покажет текущее состояние.', COMM_PREFIX+'autoaway [1|0]', [COMM_PREFIX+'autoaway 1',COMM_PREFIX+'autoaway'])
register_command_handler(handler_changebotstatus, COMM_PREFIX+'set_status', ['admin','muc','all','*'], 20, 'Меняет статус бота на указанный из списка:\naway - отсутствую,\nxa - давно отсутствую,\ndnd - не беспокоить,\nchat - хочу чатиться,\nа также статусное сообщение (если оно даётся).', COMM_PREFIX+'set_status [статус] [сообщение]', [COMM_PREFIX+'set_status away',COMM_PREFIX+'set_status away я сдох'])
register_command_handler(handler_set_nick, COMM_PREFIX+'set_nick', ['superadmin','muc','all','*'], 40, 'Меняет ник бота в текущей конференции.', COMM_PREFIX+'set_nick <nick>', [COMM_PREFIX+'set_nick somebot'])
register_command_handler(handler_remote, COMM_PREFIX+'remote', ['superadmin','muc','all','*'], 40, 'Позволяет удаленно выполнять команды и алиасы в других конференциях от имени бота и получать результат. Без параметров выводит список конференций с номерами, вместо полного названия конференции можно использовать номер из списка.', COMM_PREFIX+'remote <groupchat|номер из списка> <comm> <parameters>', [COMM_PREFIX+'remote room@conference.jabber.aq ping guy',COMM_PREFIX+'remote 2 time guy',COMM_PREFIX+'remote'])
register_command_handler(handler_redirect, COMM_PREFIX+'redirect', ['admin','muc','all','*'], 20, 'Перенаправляет результат команды или алиаса указанному пользователю в приват. Если алиас или команда не указаны и вместо них текст, или указанны неверно, то отправляет пользователю сообщение.', COMM_PREFIX+'redirect <nick>:<command>[<params>]|<mess>', [COMM_PREFIX+'redirect some guy: ping guy'])

register_stage1_init(get_autoaway_state)
register_stage1_init(set_default_gch_status)
register_message_handler(handler_delivery)
register_stage2_init(handler_admin_subscription)